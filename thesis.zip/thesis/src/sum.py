import re
from collections import defaultdict

def parse_log_file(log_file_path):
    # 初始化用于存储数据的字典
    folders = defaultdict(lambda: {'count': 0, 'duration': 0.0})
    groups = defaultdict(lambda: {'count': 0, 'duration': 0.0})

    # 正则表达式匹配文件夹和组别信息
    folder_pattern = re.compile(r'文件夹 (\S+): (\d+) 个音频，时长 ([\d.]+) 秒')
    group_pattern = re.compile(r'组别 (\S+): (\d+) 个音频，时长 ([\d.]+) 秒')

    try:
        with open(log_file_path, 'r', encoding='utf-8') as file:
            for line in file:
                # 匹配文件夹信息
                folder_match = folder_pattern.search(line)
                if folder_match:
                    folder_name = folder_match.group(1)
                    count = int(folder_match.group(2))
                    duration = float(folder_match.group(3))
                    folders[folder_name]['count'] += count
                    folders[folder_name]['duration'] += duration

                # 匹配组别信息
                group_match = group_pattern.search(line)
                if group_match:
                    group_name = group_match.group(1)
                    count = int(group_match.group(2))
                    duration = float(group_match.group(3))
                    groups[group_name]['count'] += count
                    groups[group_name]['duration'] += duration

        # 计算总计
        total_folder_count = sum(data['count'] for data in folders.values())
        total_folder_duration = sum(data['duration'] for data in folders.values())
        total_group_count = sum(data['count'] for data in groups.values())
        total_group_duration = sum(data['duration'] for data in groups.values())

        # 输出结果
        print("文件夹统计：")
        for folder, data in sorted(folders.items()):
            print(f"文件夹 {folder}: {data['count']} 个音频，时长 {data['duration']:.2f} 秒")
        print(f"\n文件夹总计：{total_folder_count} 个音频，总时长 {total_folder_duration:.2f} 秒")

        print("\n组别统计：")
        for group, data in sorted(groups.items()):
            print(f"组别 {group}: {data['count']} 个音频，时长 {data['duration']:.2f} 秒")
        print(f"\n组别总计：{total_group_count} 个音频，总时长 {total_group_duration:.2f} 秒")

    except FileNotFoundError:
        print(f"错误：文件 {log_file_path} 未找到")
    except Exception as e:
        print(f"处理文件时发生错误：{e}")

if __name__ == "__main__":
    log_file_path = "/scratch/s6070310/thesis/log/wav_duration.log"  # 替换为实际的日志文件路径
    parse_log_file(log_file_path)