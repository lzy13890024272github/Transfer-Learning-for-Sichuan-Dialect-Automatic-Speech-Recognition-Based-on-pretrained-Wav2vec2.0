import os
import logging
from pathlib import Path
from typing import Set

# 配置日志
log_dir = "/scratch/s6070310/thesis/log/data_prepare"
os.makedirs(log_dir, exist_ok=True)
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s - %(levelname)s - %(message)s",
    filename=os.path.join(log_dir, "remove_low_snr2.log"),
    filemode="w",
)
console = logging.StreamHandler()
console.setLevel(logging.INFO)
logging.getLogger("").addHandler(console)

def read_snr_list(snr_file: str) -> Set[str]:
    """读取 snr_20dB.txt 中的文件名列表。"""
    with open(snr_file, "r", encoding="utf-8") as f:
        return {line.strip() for line in f if line.strip()}

def update_transcription_file(list_file: Path, remove_files: Set[str], is_sichuan: bool = False) -> int:
    """更新转录文件，移除指定音频的条目，返回移除的记录数。"""
    updated_lines = []
    removed_count = 0
    with open(list_file, "r", encoding="utf-8") as f:
        for line in f:
            parts = line.strip().split("\t")
            if is_sichuan:
                if len(parts) >= 5 and parts[1] in remove_files:
                    removed_count += 1
                    continue
            else:
                if len(parts) == 2 and parts[0].split("/")[-1] in remove_files:
                    removed_count += 1
                    continue
            updated_lines.append(line)
    
    with open(list_file, "w", encoding="utf-8") as f:
        f.writelines(updated_lines)
    logging.info(f"更新 {list_file}: 移除 {removed_count} 条记录")
    return removed_count

def remove_low_snr_files(sichuan_root: str, scc_root: str, snr_file: str) -> None:
    """从原始数据集中删除 snr_20dB.txt 列出的音频文件，并更新转录文件。"""
    sichuan_root = Path(sichuan_root)
    scc_root = Path(scc_root)
    snr_file = Path(snr_file)
    remove_files = read_snr_list(snr_file)
    logging.info(f"读取 {len(remove_files)} 个低信噪比文件名")

    # 处理 sichuan 数据集
    sichuan_removed = 0
    sichuan_wav_dir = sichuan_root / "wav"
    if sichuan_wav_dir.exists():
        for group_folder in sichuan_wav_dir.iterdir():
            if not group_folder.is_dir():
                continue
            for wav_file in group_folder.glob("*.wav"):
                if wav_file.name in remove_files:
                    try:
                        wav_file.unlink()
                        sichuan_removed += 1
                        logging.info(f"删除 sichuan 文件: {wav_file}")
                    except Exception as e:
                        logging.error(f"删除 {wav_file} 失败: {e}")
    
    # 更新 sichuan 的 list.txt
    sichuan_list = sichuan_root / "list.txt"
    sichuan_removed_records = 0
    if sichuan_list.exists():
        sichuan_removed_records = update_transcription_file(sichuan_list, remove_files, is_sichuan=True)
    
    logging.info(f"sichuan 数据集: 删除 {sichuan_removed} 个文件，移除 {sichuan_removed_records} 条转录记录")

    # 处理 sc_dataset2 数据集
    scc_removed = 0
    scc_removed_records = 0
    for timestamp_folder in scc_root.glob("2023-04-18*"):
        wav_dir = timestamp_folder / "wavs"
        if not wav_dir.exists():
            continue
        for wav_file in wav_dir.glob("*.wav"):
            if wav_file.name in remove_files:
                try:
                    wav_file.unlink()
                    scc_removed += 1
                    logging.info(f"删除 sc_dataset2 文件: {wav_file}")
                except Exception as e:
                    logging.error(f"删除 {wav_file} 失败: {e}")
        
        # 更新时间戳文件夹的 list.txt
        list_file = timestamp_folder / "list.txt"
        if list_file.exists():
            scc_removed_records += update_transcription_file(list_file, remove_files, is_sichuan=False)

    logging.info(f"sc_dataset2 数据集: 删除 {scc_removed} 个文件，移除 {scc_removed_records} 条转录记录")
    logging.info(f"总计删除文件: {sichuan_removed + scc_removed} 个，移除转录记录: {sichuan_removed_records + scc_removed_records} 条")

if __name__ == "__main__":
    remove_low_snr_files(
        sichuan_root="/scratch/s6070310/thesis/data/sichuan",
        scc_root="/scratch/s6070310/thesis/data/sc_dataset2",
        snr_file="/scratch/s6070310/thesis/log/data_prepare/snr_20dB_sc2.txt"  # 替换为实际路径
    )