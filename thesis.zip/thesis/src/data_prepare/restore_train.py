import os
import re
import shutil
import logging
from pathlib import Path
from typing import List, Tuple, Dict

def parse_log_file(log_path: str) -> Tuple[List[str], List[str], List[str]]:
    """
    从日志文件中解析出训练集、验证集和测试集的文件路径
    返回: (train_files, val_files, test_files)
    """
    train_files = []
    val_files = []
    test_files = []
    
    # 正则表达式匹配日志中的预处理信息
    pattern = r"预处理 (.+?) 到 (.+?)$"
    
    with open(log_path, 'r', encoding='utf-8') as f:
        for line in f:
            match = re.search(pattern, line)
            if match:
                src_path = match.group(1)
                dst_path = match.group(2)
                
                # 根据目标路径判断是训练集、验证集还是测试集
                if '/train/wavs/' in dst_path:
                    train_files.append(src_path)
                elif '/val/wavs/' in dst_path:
                    val_files.append(src_path)
                elif '/test/wavs/' in dst_path:
                    test_files.append(src_path)
    
    return train_files, val_files, test_files

def get_transcription_for_file(audio_file: str, transcription_data: Dict[str, str]) -> str:
    """
    根据音频文件名获取对应的转录文本
    """
    # 提取文件名（不含路径）
    filename = os.path.basename(audio_file)
    return transcription_data.get(filename, "")

def load_sichuan_transcriptions(sichuan_root: str) -> Dict[str, str]:
    """
    加载 sichuan 数据集的转录文本
    返回: {filename: transcription}
    """
    transcriptions = {}
    list_file = Path(sichuan_root) / "list.txt"
    
    if list_file.exists():
        with open(list_file, "r", encoding="utf-8") as f:
            for line in f:
                parts = line.strip().split("\t")
                if len(parts) >= 5:
                    audio_file, transcription = parts[1], parts[4]
                    transcriptions[audio_file] = transcription
    
    return transcriptions

def load_sc_transcriptions(sc_root: str) -> Dict[str, str]:
    """
    加载 sc_dataset2 数据集的转录文本
    返回: {filename: transcription}
    """
    transcriptions = {}
    sc_root_path = Path(sc_root)
    
    # 遍历所有时间戳文件夹
    for timestamp_folder in sc_root_path.glob("2023-04-18*"):
        list_file = timestamp_folder / "list.txt"
        if list_file.exists():
            with open(list_file, "r", encoding="utf-8") as f:
                for line in f:
                    parts = line.strip().split("\t")
                    if len(parts) == 2:
                        wav_path, transcription = parts[0], parts[1]
                        audio_file = wav_path.split("/")[-1]  # 提取文件名
                        transcriptions[audio_file] = transcription
    
    return transcriptions

def reconstruct_train_set(
    log_path: str,
    sichuan_root: str,
    sc_root: str,
    output_dir: str
) -> None:
    """
    从日志文件重构训练集
    """
    # 解析日志文件，只处理训练集
    print("正在解析日志文件...")
    train_files, _, _ = parse_log_file(log_path)
    
    print(f"从日志中提取到训练集文件: {len(train_files)} 个")
    
    # 加载转录文本
    print("正在加载转录文本...")
    sichuan_transcriptions = load_sichuan_transcriptions(sichuan_root)
    sc_transcriptions = load_sc_transcriptions(sc_root)
    
    print(f"加载转录文本:")
    print(f"  Sichuan: {len(sichuan_transcriptions)} 条")
    print(f"  SC Dataset2: {len(sc_transcriptions)} 条")
    
    # 创建输出目录
    output_path = Path(output_dir)
    train_wav_dir = output_path / "wavs"
    train_wav_dir.mkdir(parents=True, exist_ok=True)
    
    # 重构训练集
    print("正在重构训练集...")
    list_file_path = output_path / "list.txt"
    
    successful_files = 0
    missing_files = 0
    missing_transcriptions = 0
    
    with open(list_file_path, "w", encoding="utf-8") as list_file:
        for src_path in train_files:
            src_path_obj = Path(src_path)
            
            # 检查源文件是否存在
            if not src_path_obj.exists():
                print(f"警告: 源文件不存在 - {src_path}")
                missing_files += 1
                continue
            
            # 提取文件名
            filename = src_path_obj.name
            
            # 获取转录文本
            transcription = ""
            if filename in sichuan_transcriptions:
                transcription = sichuan_transcriptions[filename]
            elif filename in sc_transcriptions:
                transcription = sc_transcriptions[filename]
            else:
                print(f"警告: 找不到转录文本 - {filename}")
                missing_transcriptions += 1
                continue
            
            # 复制文件到训练集目录，添加 train_ 前缀
            dst_name = f"train_{filename}"
            dst_path = train_wav_dir / dst_name
            
            try:
                shutil.copy2(src_path, dst_path)
                
                # 写入 list.txt
                list_file.write(f"wavs/{dst_name}\t{transcription}\n")
                successful_files += 1
                
                if successful_files % 100 == 0:
                    print(f"已处理 {successful_files} 个文件...")
                    
            except Exception as e:
                print(f"错误: 复制文件失败 {src_path} -> {dst_path}: {e}")
    
    # 输出统计信息
    print(f"\n重构完成!")
    print(f"成功处理: {successful_files} 个文件")
    print(f"缺失源文件: {missing_files} 个")
    print(f"缺失转录文本: {missing_transcriptions} 个")
    print(f"训练集保存至: {output_path}")
    print(f"list.txt 文件: {list_file_path}")

def main():
    """
    主函数 - 配置路径并执行重构
    """
    # 配置路径
    log_path = "/scratch/s6070310/thesis/log/data_split.log"
    sichuan_root = "/scratch/s6070310/thesis/data/original_data/sichuan"
    sc_root = "/scratch/s6070310/thesis/data/original_data/sc_dataset2"
    output_dir = "/scratch/s6070310/thesis/data/unfilter_data"
    
    # 检查必要文件是否存在
    if not os.path.exists(log_path):
        print(f"错误: 日志文件不存在 - {log_path}")
        return
    
    if not os.path.exists(sichuan_root):
        print(f"错误: Sichuan 数据目录不存在 - {sichuan_root}")
        return
    
    if not os.path.exists(sc_root):
        print(f"错误: SC Dataset2 目录不存在 - {sc_root}")
        return
    
    print("开始从日志重构训练集...")
    print(f"日志文件: {log_path}")
    print(f"Sichuan 数据: {sichuan_root}")
    print(f"SC Dataset2 数据: {sc_root}")
    print(f"输出目录: {output_dir}")
    print("-" * 50)
    
    reconstruct_train_set(log_path, sichuan_root, sc_root, output_dir)

if __name__ == "__main__":
    main()