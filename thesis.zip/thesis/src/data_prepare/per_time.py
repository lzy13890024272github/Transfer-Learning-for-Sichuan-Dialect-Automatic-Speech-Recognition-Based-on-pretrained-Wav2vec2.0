import os
import logging
from pathlib import Path
import torchaudio
from typing import Dict, List

# Configure logging
log_dir = "/scratch/s6070310/thesis/log/audio_processing"
os.makedirs(log_dir, exist_ok=True)
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s - %(levelname)s - %(message)s",
    filename=os.path.join(log_dir, "audio_length_check_unfilter_train2.log"),
    filemode="w",
)
console = logging.StreamHandler()
console.setLevel(logging.INFO)
logging.getLogger("").addHandler(console)

def load_transcriptions(list_file: str) -> Dict[str, str]:
    """Load transcriptions from list.txt into a dictionary."""
    transcriptions = {}
    with open(list_file, "r", encoding="utf-8") as f:
        for line in f:
            parts = line.strip().split("\t")
            if len(parts) == 2:
                audio_file, transcription = parts
                transcriptions[audio_file] = transcription
    return transcriptions

def get_audio_duration(audio_path: str) -> float:
    """Get the duration of an audio file in seconds."""
    try:
        waveform, sample_rate = torchaudio.load(audio_path)
        duration = waveform.shape[1] / sample_rate
        return duration
    except Exception as e:
        logging.error(f"Failed to load audio file {audio_path}: {e}")
        return 0.0

def remove_long_audios(train_dir: str, transcriptions: Dict[str, str], max_duration: float = 9.0) -> List[str]:
    """Remove audio files longer than max_duration and their transcriptions."""
    deleted_files = []
    for audio_file in list(transcriptions.keys()):
        audio_path = Path(train_dir) / audio_file
        if audio_path.exists():
            duration = get_audio_duration(str(audio_path))
            if duration > max_duration:
                try:
                    os.remove(audio_path)
                    deleted_files.append(audio_file)
                    logging.info(f"Deleted audio file: {audio_file} (duration: {duration:.2f}s)")
                except Exception as e:
                    logging.error(f"Failed to delete audio file {audio_file}: {e}")
        else:
            logging.warning(f"Audio file {audio_file} does not exist")
    
    # Remove transcriptions of deleted files
    for audio_file in deleted_files:
        del transcriptions[audio_file]
    
    return deleted_files

def update_transcription_file(list_file: str, transcriptions: Dict[str, str]):
    """Update list.txt with remaining transcriptions."""
    with open(list_file, "w", encoding="utf-8") as f:
        for audio_file, transcription in transcriptions.items():
            f.write(f"{audio_file}\t{transcription}\n")

def main():
    train_dir = "/scratch/s6070310/thesis/data/unfilter_train"
    list_file = os.path.join(train_dir, "list.txt")
    
    # Load transcriptions
    transcriptions = load_transcriptions(list_file)
    logging.info(f"Loaded transcription file: {list_file}, total records: {len(transcriptions)}")
    
    # Remove long audio files and update transcriptions
    deleted_files = remove_long_audios(train_dir, transcriptions)
    logging.info(f"Number of audio files deleted: {len(deleted_files)}")
    
    # Update transcription file
    update_transcription_file(list_file, transcriptions)
    logging.info(f"Updated transcription file: {list_file}, remaining records: {len(transcriptions)}")

if __name__ == "__main__":
    main()