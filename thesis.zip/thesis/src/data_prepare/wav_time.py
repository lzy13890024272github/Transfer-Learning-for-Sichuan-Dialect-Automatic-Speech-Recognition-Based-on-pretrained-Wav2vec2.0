#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
音频文件时长统计脚本
支持统计两种类型的音频文件：train_G开头和train_SCC开头
"""

import os
import glob
import logging
from datetime import datetime
try:
    import librosa
    USE_LIBROSA = True
except ImportError:
    try:
        import soundfile as sf
        USE_LIBROSA = False
        USE_SOUNDFILE = True
    except ImportError:
        import wave
        import contextlib
        USE_LIBROSA = False
        USE_SOUNDFILE = False
        logging.warning("建议安装 librosa 或 soundfile 库以支持更多音频格式: pip install librosa 或 pip install soundfile")

def setup_logging():
    # 指定具体的保存目录
    log_dir = "/scratch/s6070310/thesis/log/audio_processing"  # 或者你想要的任何路径
    os.makedirs(log_dir, exist_ok=True)  # 确保目录存在
    log_filename = os.path.join(log_dir, f"cal_val_wav")
    logging.basicConfig(
        level=logging.INFO,
        format='%(asctime)s - %(levelname)s - %(message)s',
        handlers=[
            logging.FileHandler(log_filename, encoding='utf-8'),
            logging.StreamHandler()
        ]
    )
    return log_filename

def get_wav_duration(wav_file):
    """
    获取wav文件的时长（秒）
    支持多种音频格式
    """
    try:
        if USE_LIBROSA:
            # 使用librosa，支持更多格式
            duration = librosa.get_duration(path=wav_file)
            return duration
        elif 'USE_SOUNDFILE' in globals() and USE_SOUNDFILE:
            # 使用soundfile
            with sf.SoundFile(wav_file) as f:
                duration = len(f) / f.samplerate
                return duration
        else:
            # 回退到wave模块
            with contextlib.closing(wave.open(wav_file, 'r')) as f:
                frames = f.getnframes()
                rate = f.getframerate()
                duration = frames / float(rate)
                return duration
    except Exception as e:
        logging.error(f"读取文件 {os.path.basename(wav_file)} 时出错: {e}")
        return 0

def format_duration(seconds):
    """
    将秒数转换为时:分:秒格式
    """
    hours = int(seconds // 3600)
    minutes = int((seconds % 3600) // 60)
    secs = seconds % 60
    return f"{hours:02d}:{minutes:02d}:{secs:06.3f}"

def classify_audio_files(wav_path):
    """
    分类音频文件
    """
    if not os.path.exists(wav_path):
        logging.error(f"路径不存在: {wav_path}")
        return [], []
    
    # 查找所有wav文件
    wav_pattern = os.path.join(wav_path, "*.wav")
    all_wav_files = glob.glob(wav_pattern)
    
    train_g_files = []
    train_scc_files = []
    other_files = []
    
    for wav_file in all_wav_files:
        filename = os.path.basename(wav_file)
        if filename.startswith("val_G"):
            train_g_files.append(wav_file)
        elif filename.startswith("val_SCC"):
            train_scc_files.append(wav_file)
        else:
            other_files.append(wav_file)
    
    if other_files:
        logging.warning(f"发现 {len(other_files)} 个不符合命名规则的文件:")
        for file in other_files[:5]:  # 只显示前5个
            logging.warning(f"  - {os.path.basename(file)}")
        if len(other_files) > 5:
            logging.warning(f"  ... 还有 {len(other_files) - 5} 个文件")
    
    return train_g_files, train_scc_files

def calculate_duration_stats(files, file_type):
    """
    计算指定类型文件的时长统计
    """
    if not files:
        logging.info(f"{file_type} 类型的文件数量: 0")
        return 0, 0, 0
    
    total_duration = 0
    valid_files = 0
    
    logging.info(f"\n开始处理 {file_type} 类型文件...")
    
    for wav_file in files:
        duration = get_wav_duration(wav_file)
        if duration > 0:
            total_duration += duration
            valid_files += 1
            logging.debug(f"{os.path.basename(wav_file)}: {format_duration(duration)}")
    
    avg_duration = total_duration / valid_files if valid_files > 0 else 0
    
    logging.info(f"{file_type} 统计结果:")
    logging.info(f"  文件总数: {len(files)}")
    logging.info(f"  有效文件: {valid_files}")
    logging.info(f"  总时长: {format_duration(total_duration)}")
    logging.info(f"  平均时长: {format_duration(avg_duration)}")
    
    return total_duration, valid_files, len(files)

def main():
    """主函数"""
    # 设置日志
    log_file = setup_logging()
    logging.info("="*60)
    logging.info("音频文件时长统计开始")
    logging.info("="*60)
    
    # 显示使用的音频库
    if USE_LIBROSA:
        logging.info("使用 librosa 库读取音频文件")
    elif 'USE_SOUNDFILE' in globals() and USE_SOUNDFILE:
        logging.info("使用 soundfile 库读取音频文件")
    else:
        logging.info("使用 wave 库读取音频文件（可能不支持某些格式）")
    
    # 获取音频文件夹路径
    wav_path = "/scratch/s6070310/thesis/data/val/wavs"
    
    # 去除可能的引号
    if wav_path.startswith('"') and wav_path.endswith('"'):
        wav_path = wav_path[1:-1]
    elif wav_path.startswith("'") and wav_path.endswith("'"):
        wav_path = wav_path[1:-1]
    
    logging.info(f"音频文件夹路径: {wav_path}")
    
    # 分类音频文件
    train_g_files, train_scc_files = classify_audio_files(wav_path)
    
    # 统计train_G类型文件
    g_total, g_valid, g_count = calculate_duration_stats(train_g_files, "val_G")
    
    # 统计train_SCC类型文件
    scc_total, scc_valid, scc_count = calculate_duration_stats(train_scc_files, "val_SCC")
    
    # 总体统计
    total_files = g_count + scc_count
    total_valid = g_valid + scc_valid
    total_duration = g_total + scc_total
    
    logging.info("\n" + "="*60)
    logging.info("最终统计结果")
    logging.info("="*60)
    logging.info(f"val_G 类型:")
    logging.info(f"  文件数量: {g_count}")
    logging.info(f"  有效文件: {g_valid}")
    logging.info(f"  总时长: {format_duration(g_total)}")
    
    logging.info(f"\nval_SCC 类型:")
    logging.info(f"  文件数量: {scc_count}")
    logging.info(f"  有效文件: {scc_valid}")
    logging.info(f"  总时长: {format_duration(scc_total)}")
    
    logging.info(f"\n整体统计:")
    logging.info(f"  文件总数: {total_files}")
    logging.info(f"  有效文件: {total_valid}")
    logging.info(f"  总时长: {format_duration(total_duration)}")
    
    if total_files > 0:
        logging.info(f"  平均时长: {format_duration(total_duration / total_valid if total_valid > 0 else 0)}")
    
    # 显示失败文件统计
    failed_files = total_files - total_valid
    if failed_files > 0:
        logging.warning(f"  读取失败文件: {failed_files}")
        logging.warning("建议安装 librosa 库以支持更多音频格式: pip install librosa")
    
    logging.info(f"\n日志文件已保存至: {log_file}")
    logging.info("统计完成!")

if __name__ == "__main__":
    main()