import os
import logging
from pathlib import Path
import torchaudio
from typing import Dict, Tuple

# 配置日志
log_dir = "/scratch/s6070310/thesis/log"
os.makedirs(log_dir, exist_ok=True)
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s - %(levelname)s - %(message)s",
    filename=os.path.join(log_dir, "wav_duration_within9s.log"),
    filemode="w",
)
console = logging.StreamHandler()
console.setLevel(logging.INFO)
logging.getLogger("").addHandler(console)

def get_wav_duration(audio_path: str) -> float:
    """获取单个 WAV 文件的时长（秒）。"""
    try:
        info = torchaudio.info(audio_path)
        duration = info.num_frames / info.sample_rate
        return duration
    except Exception as e:
        logging.error(f"无法读取 {audio_path}: {e}")
        return 0.0

def calculate_folder_durations(root_path: str, is_sichuan: bool = False) -> Tuple[Dict[str, float], float]:
    """计算每个文件夹中 WAV 文件的总时长。
    
    参数:
        root_path: 数据集根目录（如 'thesis/data/sc_dataset2' 或 'thesis/data/sichuan'）。
        is_sichuan: 是否为 sichuan 数据集（True 时处理 wav/<group> 结构）。
    
    返回:
        folder_durations: 字典，键为文件夹路径，值为总时长（秒）。
        total_duration: 所有文件夹的总时长（秒）。
    """
    folder_durations = {}
    total_duration = 0.0
    root = Path(root_path)

    if is_sichuan:
        # sichuan 结构：wav/<group>/*.wav
        wav_dir = root / "wav"
        if not wav_dir.exists():
            logging.error(f"WAV 目录不存在: {wav_dir}")
            return folder_durations, total_duration

        # 遍历组别文件夹（如 G0001）
        for group_folder in wav_dir.iterdir():
            if group_folder.is_dir():
                duration = 0.0
                wav_count = 0
                for wav_file in group_folder.glob("*.wav"):
                    duration += get_wav_duration(wav_file)
                    wav_count += 1
                folder_durations[str(group_folder)] = duration
                total_duration += duration
                logging.info(f"组别 {group_folder.name}: {wav_count} 个音频，时长 {duration:.2f} 秒")
    else:
        # sc_dataset2 结构：<时间戳>/wavs/*.wav
        for timestamp_folder in root.glob("2023-04-18*"):
            if timestamp_folder.is_dir():
                wav_dir = timestamp_folder / "wavs"
                if not wav_dir.exists():
                    logging.warning(f"WAV 目录不存在: {wav_dir}")
                    continue
                duration = 0.0
                wav_count = 0
                for wav_file in wav_dir.glob("*.wav"):
                    duration += get_wav_duration(wav_file)
                    wav_count += 1
                folder_durations[str(timestamp_folder)] = duration
                total_duration += duration
                logging.info(f"文件夹 {timestamp_folder.name}: {wav_count} 个音频，时长 {duration:.2f} 秒")

    return folder_durations, total_duration

def format_duration(seconds: float) -> str:
    """将秒数格式化为小时、分钟、秒。"""
    hours = int(seconds // 3600)
    minutes = int((seconds % 3600) // 60)
    secs = seconds % 60
    return f"{hours}小时 {minutes}分钟 {secs:.2f}秒"

def main():
    # 数据集路径
    sc_dataset2_path = "/scratch/s6070310/thesis/data/sc_dataset2"
    sichuan_path = "/scratch/s6070310/thesis/data/sichuan"

    # 计算 sc_dataset2 时长
    logging.info("计算 sc_dataset2 数据集时长...")
    sc_folders, sc_total = calculate_folder_durations(sc_dataset2_path, is_sichuan=False)
    print("\n=== sc_dataset2 时长 ===")
    for folder, duration in sc_folders.items():
        print(f"{folder}: {format_duration(duration)} ({duration:.2f} 秒)")
    print(f"总时长: {format_duration(sc_total)} ({sc_total:.2f} 秒)")

    # 计算 sichuan 时长
    logging.info("计算 sichuan 数据集时长...")
    sichuan_folders, sichuan_total = calculate_folder_durations(sichuan_path, is_sichuan=True)
    print("\n=== sichuan 时长 ===")
    for folder, duration in sichuan_folders.items():
        print(f"{folder}: {format_duration(duration)} ({duration:.2f} 秒)")
    print(f"总时长: {format_duration(sichuan_total)} ({sichuan_total:.2f} 秒)")

    # 总计
    overall_total = sc_total + sichuan_total
    print("\n=== 整体时长 ===")
    print(f"sc_dataset2 + sichuan 总时长: {format_duration(overall_total)} ({overall_total:.2f} 秒)")

if __name__ == "__main__":
    main()