import os
import librosa

def check_sample_rate(directory, target_sr=16000):
    """
    检查目录中所有音频文件的采样率是否为目标采样率（默认为16kHz）
    
    参数:
        directory (str): 音频文件目录路径
        target_sr (int): 目标采样率（默认16000）
    
    返回:
        dict: 包含检查结果的字典，包括通过/失败的文件列表和统计信息
    """
    results = {
        'passed': [],
        'failed': [],
        'total_files': 0,
        'correct_sr': 0,
        'wrong_sr': 0
    }
    
    # 获取目录中所有音频文件（支持常见音频格式）
    audio_extensions = ['.wav', '.mp3', '.flac', '.ogg', '.aac']
    audio_files = [f for f in os.listdir(directory) 
                  if os.path.splitext(f)[1].lower() in audio_extensions]
    
    if not audio_files:
        print(f"警告: 目录 {directory} 中没有找到音频文件")
        return results
    
    results['total_files'] = len(audio_files)
    
    for filename in audio_files:
        filepath = os.path.join(directory, filename)
        try:
            # 加载音频文件（不加载音频数据，只获取元数据）
            sr = librosa.get_samplerate(filepath)
            
            if sr == target_sr:
                results['passed'].append(filename)
                results['correct_sr'] += 1
            else:
                results['failed'].append((filename, sr))
                results['wrong_sr'] += 1
                
        except Exception as e:
            print(f"处理文件 {filename} 时出错: {str(e)}")
            results['failed'].append((filename, f"Error: {str(e)}"))
            results['wrong_sr'] += 1
    
    return results

def print_results(results):
    """打印检查结果"""
    print("\n检查结果:")
    print(f"总文件数: {results['total_files']}")
    print(f"正确采样率(16kHz)的文件数: {results['correct_sr']}")
    print(f"错误采样率的文件数: {results['wrong_sr']}")
    
    if results['failed']:
        print("\n错误采样率的文件:")
        for item in results['failed']:
            if isinstance(item, tuple):
                print(f"- {item[0]}: 实际采样率 = {item[1]}Hz")
            else:
                print(f"- {item}: 无法读取采样率")

if __name__ == "__main__":
    # 设置音频目录路径
    audio_dir = "/scratch/s6070310/thesis/data/test/wavs"
          
    # 检查目录是否存在
    if not os.path.exists(audio_dir):
        print(f"错误: 目录 {audio_dir} 不存在")
    else:
        # 执行检查
        results = check_sample_rate(audio_dir)
        
        # 打印结果
        print_results(results)