import os
import numpy as np
import librosa
from tqdm import tqdm
import logging
from datetime import datetime
from pathlib import Path

# ===== 固定配置 =====
AUDIO_DIR = "/scratch/s6070310/thesis/data/sc_dataset2"  # 替换为你的实际路径
MIN_SNR = 20  # 设定最低允许的 SNR (dB)
LOG_DIR = "/scratch/s6070310/thesis/log/data_prepare"  # 日志目录
LOG_FILE = "snr_check3.log"  # 日志文件名
OUTPUT_FILE = "/scratch/s6070310/thesis/data/snr_20dB.txt"  # 输出低 SNR 文件列表
# ==================

def setup_logging():
    """配置日志系统"""
    os.makedirs(LOG_DIR, exist_ok=True)
    log_path = os.path.join(LOG_DIR, LOG_FILE)
    
    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s - %(message)s",
        handlers=[
            logging.FileHandler(log_path, mode='a'),  # 追加模式
            logging.StreamHandler()  # 同时输出到控制台
        ]
    )
    return logging.getLogger()

logger = setup_logging()

def calculate_snr(audio, sr=16000, noise_window_size=2048):
    """计算音频的信噪比 (SNR)"""
    signal_power = np.mean(audio ** 2)
    noise_segment = audio[:noise_window_size]
    noise_power = np.mean(noise_segment ** 2)
    return 10 * np.log10(signal_power / (noise_power + 1e-10))  # 避免除零

def check_audio_snr(root_dir, min_snr):
    """检查 sc_dataset2 中所有时间戳文件夹下音频文件的 SNR"""
    results = {
        'passed': [], 'failed': [],
        'snr_stats': {'min': float('inf'), 'max': -float('inf'), 'avg': 0}
    }
    
    root_path = Path(root_dir)
    snr_list = []
    
    # 遍历所有时间戳文件夹
    for timestamp_folder in root_path.glob("2023-04-18*"):
        wav_dir = timestamp_folder / "wavs"
        if not wav_dir.exists():
            logger.warning(f"WAV 目录不存在: {wav_dir}")
            continue
        
        # 获取音频文件
        audio_files = [f for f in wav_dir.glob("*.wav")]
        
        if not audio_files:
            logger.warning(f"目录 {wav_dir} 中没有音频文件！")
            continue
        
        for wav_file in tqdm(audio_files, desc=f"计算 SNR ({timestamp_folder.name})"):
            try:
                audio, _ = librosa.load(wav_file, sr=16000, mono=True)
                snr = calculate_snr(audio)
                snr_list.append(snr)
                
                if snr >= min_snr:
                    results['passed'].append((wav_file.name, snr))
                else:
                    results['failed'].append((wav_file.name, snr))
            except Exception as e:
                logger.error(f"处理 {wav_file} 出错: {e}")
                results['failed'].append((wav_file.name, f"Error: {str(e)}"))
    
    if snr_list:
        results['snr_stats'] = {
            'min': min(snr_list),
            'max': max(snr_list),
            'avg': np.mean(snr_list)
        }
    
    return results

def log_results(root_dir, results, min_snr):
    """记录结果到日志文件并保存低 SNR 文件列表"""
    logger.info(f"\n{'='*50}")
    logger.info(f"📅 检测时间: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    logger.info(f"📂 检测目录: {root_dir}")
    logger.info(f"📊 SNR 统计:")
    logger.info(f"  - 最低: {results['snr_stats']['min']:.2f} dB")
    logger.info(f"  - 最高: {results['snr_stats']['max']:.2f} dB")
    logger.info(f"  - 平均: {results['snr_stats']['avg']:.2f} dB")
    logger.info(f"  - 阈值: >{min_snr} dB")
    logger.info(f"✅ 通过: {len(results['passed'])} 个文件")
    logger.info(f"❌ 失败: {len(results['failed'])} 个文件")
    
    if results['failed']:
        logger.info("\n失败文件详情:")
        with open(OUTPUT_FILE, "w", encoding="utf-8") as f:
            for filename, snr in results['failed']:
                if isinstance(snr, float):
                    logger.info(f"  - {filename}: {snr:.2f} dB")
                    f.write(f"{filename}\n")
                else:
                    logger.info(f"  - {filename}: {snr}")

if __name__ == "__main__":
    # 检查根目录是否存在
    if not os.path.exists(AUDIO_DIR):
        logger.error(f"目录 {AUDIO_DIR} 不存在！")
        exit(1)
    
    # 执行检测并记录日志
    results = check_audio_snr(AUDIO_DIR, MIN_SNR)
    log_results(AUDIO_DIR, results, MIN_SNR)
    
    # 打印摘要到控制台
    print(f"\n检测完成！日志已保存至: {os.path.join(LOG_DIR, LOG_FILE)}")
    print(f"低 SNR 文件列表已保存至: {OUTPUT_FILE}")