import os
import numpy as np
import librosa
from tqdm import tqdm
import logging
from datetime import datetime

# ===== 固定配置 =====
AUDIO_DIR = "/scratch/s6070310/thesis/data/train/wavs"  # 替换为你的实际路径
MIN_SNR = 20  # 设定最低允许的 SNR (dB)
LOG_DIR = "/scratch/s6070310/thesis/log/data_prepare"  # 日志目录
LOG_FILE = "snr_check2.log"  # 日志文件名
# ==================

def setup_logging():
    """配置日志系统"""
    os.makedirs(LOG_DIR, exist_ok=True)
    log_path = os.path.join(LOG_DIR, LOG_FILE)
    
    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s - %(message)s",
        handlers=[
            logging.FileHandler(log_path, mode='a'),  # 追加模式
            logging.StreamHandler()  # 同时输出到控制台
        ]
    )
    return logging.getLogger()

logger = setup_logging()

def calculate_snr(audio, sr=16000, noise_window_size=2048):
    """计算音频的信噪比 (SNR)"""
    signal_power = np.mean(audio ** 2)
    noise_segment = audio[:noise_window_size]
    noise_power = np.mean(noise_segment ** 2)
    return 10 * np.log10(signal_power / (noise_power + 1e-10))  # 避免除零

def check_audio_snr(directory, min_snr):
    """检查目录下所有音频文件的 SNR 是否达标"""
    results = {
        'passed': [], 'failed': [],
        'snr_stats': {'min': float('inf'), 'max': -float('inf'), 'avg': 0}
    }
    
    audio_files = [f for f in os.listdir(directory) 
                  if f.lower().endswith(('.wav', '.mp3', '.flac', '.ogg', '.aac'))]
    
    if not audio_files:
        logger.warning(f"目录 {directory} 中没有音频文件！")
        return results
    
    snr_list = []
    for filename in tqdm(audio_files, desc="计算 SNR"):
        try:
            audio, _ = librosa.load(os.path.join(directory, filename), sr=16000, mono=True)
            snr = calculate_snr(audio)
            snr_list.append(snr)
            
            if snr >= min_snr:
                results['passed'].append((filename, snr))
            else:
                results['failed'].append((filename, snr))
        except Exception as e:
            logger.error(f"处理 {filename} 出错: {e}")
            results['failed'].append((filename, f"Error: {str(e)}"))
    
    if snr_list:
        results['snr_stats'] = {
            'min': min(snr_list),
            'max': max(snr_list),
            'avg': np.mean(snr_list)
        }
    
    return results

def log_results(directory, results, min_snr):
    """记录结果到日志文件"""
    logger.info(f"\n{'='*50}")
    logger.info(f"📅 检测时间: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    logger.info(f"📂 检测目录: {directory}")
    logger.info(f"📊 SNR 统计:")
    logger.info(f"  - 最低: {results['snr_stats']['min']:.2f} dB")
    logger.info(f"  - 最高: {results['snr_stats']['max']:.2f} dB")
    logger.info(f"  - 平均: {results['snr_stats']['avg']:.2f} dB")
    logger.info(f"  - 阈值: >{min_snr} dB")
    logger.info(f"✅ 通过: {len(results['passed'])} 个文件")
    logger.info(f"❌ 失败: {len(results['failed'])} 个文件")
    
    if results['failed']:
        logger.info("\n失败文件详情:")
        for filename, snr in results['failed']:
            if isinstance(snr, float):
                logger.info(f"  - {filename}: {snr:.2f} dB")
            else:
                logger.info(f"  - {filename}: {snr}")

if __name__ == "__main__":
    # 检查目录是否存在
    if not os.path.exists(AUDIO_DIR):
        logger.error(f"目录 {AUDIO_DIR} 不存在！")
        exit(1)
    
    # 执行检测并记录日志
    results = check_audio_snr(AUDIO_DIR, MIN_SNR)
    log_results(AUDIO_DIR, results, MIN_SNR)
    
    # 打印摘要到控制台
    print(f"\n检测完成！日志已保存至: {os.path.join(LOG_DIR, LOG_FILE)}")