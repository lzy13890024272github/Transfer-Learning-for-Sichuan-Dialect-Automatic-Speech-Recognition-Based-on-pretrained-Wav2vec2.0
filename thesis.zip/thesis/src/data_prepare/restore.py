import os
import shutil
import logging
from pathlib import Path
from typing import List, Dict

def load_sichuan_transcriptions(sichuan_root: str) -> Dict[str, str]:
    """
    加载 sichuan 数据集的转录文本
    返回: {filename: transcription}
    """
    transcriptions = {}
    list_file = Path(sichuan_root) / "list.txt"
    
    if list_file.exists():
        with open(list_file, "r", encoding="utf-8") as f:
            for line in f:
                parts = line.strip().split("\t")
                if len(parts) >= 5:
                    audio_file, transcription = parts[1], parts[4]
                    transcriptions[audio_file] = transcription
    
    return transcriptions

def load_sc_transcriptions(sc_root: str) -> Dict[str, str]:
    """
    加载 sc_dataset2 数据集的转录文本
    返回: {filename: transcription}
    """
    transcriptions = {}
    sc_root_path = Path(sc_root)
    
    # 遍历所有时间戳文件夹
    for timestamp_folder in sc_root_path.glob("2023-04-18*"):
        list_file = timestamp_folder / "list.txt"
        if list_file.exists():
            with open(list_file, "r", encoding="utf-8") as f:
                for line in f:
                    parts = line.strip().split("\t")
                    if len(parts) == 2:
                        wav_path, transcription = parts[0], parts[1]
                        audio_file = wav_path.split("/")[-1]  # 提取文件名
                        transcriptions[audio_file] = transcription
    
    return transcriptions

def read_filtered_paths(filter_log_path: str) -> List[str]:
    """
    读取被过滤文件的路径列表
    """
    filtered_paths = []
    with open(filter_log_path, "r", encoding="utf-8") as f:
        for line in f:
            path = line.strip()
            if path:  # 忽略空行
                filtered_paths.append(path)
    
    return filtered_paths

def restore_filtered_files(
    filter_log_path: str,
    sichuan_root: str,
    sc_root: str,
    unfilter_data_dir: str
) -> None:
    """
    恢复被过滤的文件到 unfilter_data 目录
    """
    # 读取被过滤的文件列表
    print("正在读取被过滤的文件列表...")
    filtered_paths = read_filtered_paths(filter_log_path)
    print(f"找到 {len(filtered_paths)} 个被过滤的文件")
    
    # 加载转录文本
    print("正在加载转录文本...")
    sichuan_transcriptions = load_sichuan_transcriptions(sichuan_root)
    sc_transcriptions = load_sc_transcriptions(sc_root)
    
    print(f"加载转录文本:")
    print(f"  Sichuan: {len(sichuan_transcriptions)} 条")
    print(f"  SC Dataset2: {len(sc_transcriptions)} 条")
    
    # 确保输出目录存在
    unfilter_path = Path(unfilter_data_dir)
    wav_dir = unfilter_path / "wavs"
    wav_dir.mkdir(parents=True, exist_ok=True)
    
    list_file_path = unfilter_path / "list.txt"
    
    # 统计信息
    successful_files = 0
    missing_files = 0
    missing_transcriptions = 0
    skipped_existing = 0
    
    # 读取现有的 list.txt 来检查重复
    existing_files = set()
    if list_file_path.exists():
        with open(list_file_path, "r", encoding="utf-8") as f:
            for line in f:
                if line.strip():
                    wav_path = line.split("\t")[0]
                    existing_files.add(wav_path)
    
    print(f"现有 list.txt 中已有 {len(existing_files)} 个文件")
    
    # 以追加模式打开 list.txt
    with open(list_file_path, "a", encoding="utf-8") as list_file:
        for src_path in filtered_paths:
            src_path_obj = Path(src_path)
            
            # 检查源文件是否存在
            if not src_path_obj.exists():
                print(f"警告: 源文件不存在 - {src_path}")
                missing_files += 1
                continue
            
            # 提取文件名
            filename = src_path_obj.name
            
            # 生成目标文件名
            dst_name = f"train_{filename}"
            dst_wav_path = f"wavs/{dst_name}"
            
            # 检查是否已经存在
            if dst_wav_path in existing_files:
                print(f"跳过已存在的文件: {dst_name}")
                skipped_existing += 1
                continue
            
            # 获取转录文本
            transcription = ""
            if filename in sichuan_transcriptions:
                transcription = sichuan_transcriptions[filename]
            elif filename in sc_transcriptions:
                transcription = sc_transcriptions[filename]
            else:
                print(f"警告: 找不到转录文本 - {filename}")
                missing_transcriptions += 1
                continue
            
            # 复制文件到目标目录
            dst_path = wav_dir / dst_name
            
            try:
                shutil.copy2(src_path, dst_path)
                
                # 写入 list.txt（追加模式）
                list_file.write(f"{dst_wav_path}\t{transcription}\n")
                existing_files.add(dst_wav_path)  # 更新已存在文件集合
                successful_files += 1
                
                if successful_files % 100 == 0:
                    print(f"已处理 {successful_files} 个文件...")
                    
            except Exception as e:
                print(f"错误: 复制文件失败 {src_path} -> {dst_path}: {e}")
    
    # 输出统计信息
    print(f"\n恢复完成!")
    print(f"成功添加: {successful_files} 个文件")
    print(f"跳过已存在: {skipped_existing} 个文件")
    print(f"缺失源文件: {missing_files} 个")
    print(f"缺失转录文本: {missing_transcriptions} 个")
    
    # 统计最终的文件数量
    total_lines = 0
    with open(list_file_path, "r", encoding="utf-8") as f:
        total_lines = sum(1 for line in f if line.strip())
    
    print(f"最终 list.txt 包含: {total_lines} 个文件")
    print(f"文件保存至: {unfilter_path}")

def main():
    """
    主函数
    """
    # 配置路径
    filter_log_path = "/scratch/s6070310/thesis/log/data_prepare/snr20filter_path.log"
    sichuan_root = "/scratch/s6070310/thesis/data/original_data/sichuan"
    sc_root = "/scratch/s6070310/thesis/data/original_data/sc_dataset2"
    unfilter_data_dir = "/scratch/s6070310/thesis/data/unfilter_train"
    
    # 检查必要文件是否存在
    if not os.path.exists(filter_log_path):
        print(f"错误: 过滤日志文件不存在 - {filter_log_path}")
        return
    
    if not os.path.exists(sichuan_root):
        print(f"错误: Sichuan 数据目录不存在 - {sichuan_root}")
        return
    
    if not os.path.exists(sc_root):
        print(f"错误: SC Dataset2 目录不存在 - {sc_root}")
        return
    
    if not os.path.exists(unfilter_data_dir):
        print(f"错误: unfilter_data 目录不存在 - {unfilter_data_dir}")
        print("请先运行训练集重构脚本创建 unfilter_data 目录")
        return
    
    print("开始恢复被过滤的文件...")
    print(f"过滤日志: {filter_log_path}")
    print(f"Sichuan 数据: {sichuan_root}")
    print(f"SC Dataset2 数据: {sc_root}")
    print(f"目标目录: {unfilter_data_dir}")
    print("-" * 50)
    
    restore_filtered_files(filter_log_path, sichuan_root, sc_root, unfilter_data_dir)

if __name__ == "__main__":
    main()