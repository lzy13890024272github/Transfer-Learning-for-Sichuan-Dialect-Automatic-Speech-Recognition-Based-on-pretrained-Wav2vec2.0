import os
import logging
import random
import shutil
from pathlib import Path
import torchaudio
from typing import List, Tuple, Dict

# 配置日志
log_dir = "/scratch/s6070310/thesis/log"
os.makedirs(log_dir, exist_ok=True)
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s - %(levelname)s - %(message)s",
    filename=os.path.join(log_dir, "data_split.log"),
    filemode="w",
)
console = logging.StreamHandler()
console.setLevel(logging.INFO)
logging.getLogger("").addHandler(console)

def get_wav_duration(audio_path: str) -> float:
    """获取 WAV 文件时长（秒）。"""
    try:
        info = torchaudio.info(audio_path)
        return info.num_frames / info.sample_rate
    except Exception as e:
        logging.error(f"无法读取 {audio_path}: {e}")
        return 0.0

def read_sichuan_transcriptions(file_path: str) -> List[Tuple[str, str, str]]:
    """读取 sichuan 的 list.txt，提取文件名、组别、转录文本。"""
    transcriptions = []
    with open(file_path, "r", encoding="utf-8") as f:
        for line in f:
            parts = line.strip().split("\t")
            if len(parts) >= 5:
                audio_file, group, transcription = parts[1], parts[2], parts[4]
                transcriptions.append((audio_file, group, transcription))
    return transcriptions

def read_sc_transcriptions(folder_path: Path) -> List[Tuple[str, str]]:
    """读取 sc_dataset2 所有时间戳文件夹的 list.txt，提取文件名和转录文本。"""
    transcriptions = []
    for timestamp_folder in folder_path.glob("2023-04-18*"):
        list_file = timestamp_folder / "list.txt"
        if list_file.exists():
            with open(list_file, "r", encoding="utf-8") as f:
                for line in f:
                    parts = line.strip().split("\t")
                    if len(parts) == 2:
                        wav_path, transcription = parts[0], parts[1]
                        audio_file = wav_path.split("/")[-1]
                        transcriptions.append((audio_file, transcription))
    return transcriptions

def preprocess_audio(src_path: str, dst_path: str) -> bool:
    """预处理音频：标准化为 16kHz 单声道，降噪（sc_dataset2）。"""
    try:
        waveform, sample_rate = torchaudio.load(src_path)
        if sample_rate != 16000:
            resampler = torchaudio.transforms.Resample(sample_rate, 16000)
            waveform = resampler(waveform)
        if waveform.shape[0] > 1:
            waveform = waveform.mean(dim=0, keepdim=True)
        torchaudio.save(dst_path, waveform, 16000)
        # 模拟降噪：实际需用 Sox 命令（如 'sox src.wav dst.wav noisered noise.prof 0.21'）
        logging.info(f"预处理 {src_path} 到 {dst_path}")
        return True
    except Exception as e:
        logging.error(f"预处理 {src_path} 失败: {e}")
        return False

def split_dataset(
    sichuan_root: str,
    scc_root: str,
    output_dir: str,
    train_sch_hours: float = 5.4,
    train_sc_hours: float = 3.6,
    val_sch_hours: float = 0.5,
    val_sc_hours: float = 0.5,
    test_sch_hours: float = 1.0
) -> None:
    """划分数据集为训练、验证、测试集，并保存。"""
    sichuan_root = Path(sichuan_root)
    scc_root = Path(scc_root)
    output_root = Path(output_dir)
    unified_wav_dir = output_root / "unified_wavs"
    train_dir = output_root / "train"
    val_dir = output_root / "val"
    test_dir = output_root / "test"
    
    for d in [unified_wav_dir, train_dir, val_dir, test_dir]:
        d.mkdir(parents=True, exist_ok=True)

    # 读取 sichuan 数据
    sichuan_transcripts = read_sichuan_transcriptions(sichuan_root / "list.txt")
    sichuan_files = []
    for audio_file, group, text in sichuan_transcripts:
        src_path = sichuan_root / "wav" / group / audio_file
        if src_path.exists():
            duration = get_wav_duration(src_path)
            sichuan_files.append((src_path, text, duration, group))

    # 读取 sc_dataset2 数据
    scc_transcripts = read_sc_transcriptions(scc_root)
    scc_files = []
    for audio_file, text in scc_transcripts:
        for ts_folder in scc_root.glob("2023-04-18*"):
            src_path = ts_folder / "wavs" / audio_file
            if src_path.exists():
                duration = get_wav_duration(src_path)
                scc_files.append((src_path, text, duration, ts_folder.name))
                break

    # 按组别分组 sichuan 数据，确保测试集未见说话者
    sichuan_by_group: Dict[str, List] = {}
    for item in sichuan_files:
        group = item[3]
        sichuan_by_group.setdefault(group, []).append(item)

    # 随机选择组别用于测试集
    random.seed(42)  # 固定种子以确保可重复性
    groups = list(sichuan_by_group.keys())
    random.shuffle(groups)
    test_groups = []
    test_duration = 0.0
    for group in groups:
        group_duration = sum(item[2] for item in sichuan_by_group[group])
        if test_duration + group_duration <= test_sch_hours * 3600:
            test_groups.append(group)
            test_duration += group_duration
        else:
            break

    # 划分 sichuan 数据
    train_sch_files, val_sch_files, test_sch_files = [], [], []
    train_sch_duration, val_sch_duration = 0.0, 0.0
    for group, items in sichuan_by_group.items():
        if group in test_groups:
            test_sch_files.extend(items)
        else:
            random.shuffle(items)
            group_duration = sum(item[2] for item in items)
            val_target = group_duration * (val_sch_hours / (train_sch_hours + val_sch_hours))
            for item in items:
                if val_sch_duration < val_sch_hours * 3600 and random.random() < val_target / group_duration:
                    val_sch_files.append(item)
                    val_sch_duration += item[2]
                else:
                    train_sch_files.append(item)
                    train_sch_duration += item[2]
                group_duration -= item[2]

    # 划分 sc_dataset2 数据
    random.shuffle(scc_files)
    train_sc_files, val_sc_files = [], []
    train_sc_duration, val_sc_duration = 0.0, 0.0
    for item in scc_files:
        if train_sc_duration < train_sc_hours * 3600:
            train_sc_files.append(item)
            train_sc_duration += item[2]
        elif val_sc_duration < val_sc_hours * 3600:
            val_sc_files.append(item)
            val_sc_duration += item[2]
        else:
            break

    # 保存数据集
    def save_subset(files: List, subset_dir: Path, subset_name: str) -> float:
        wav_dir = subset_dir / "wavs"
        wav_dir.mkdir(exist_ok=True)
        list_file = subset_dir / "list.txt"
        total_duration = 0.0
        with open(list_file, "w", encoding="utf-8") as f:
            for src_path, text, duration, _ in files:
                total_duration += duration
                dst_name = f"{subset_name}_{src_path.name}"
                dst_path = wav_dir / dst_name
                if preprocess_audio(src_path, dst_path):
                    f.write(f"wavs/{dst_name}\t{text}\n")
        return total_duration

    # 保存训练、验证、测试集
    train_duration = save_subset(train_sch_files + train_sc_files, train_dir, "train")
    val_duration = save_subset(val_sch_files + val_sc_files, val_dir, "val")
    test_duration = save_subset(test_sch_files, test_dir, "test")

    # 日志和输出
    logging.info(f"训练集: {len(train_sch_files)} sichuan + {len(train_sc_files)} sc_dataset2, 时长 {train_duration/3600:.2f} 小时")
    logging.info(f"验证集: {len(val_sch_files)} sichuan + {len(val_sc_files)} sc_dataset2, 时长 {val_duration/3600:.2f} 小时")
    logging.info(f"测试集: {len(test_sch_files)} sichuan, 时长 {test_duration/3600:.2f} 小时")
    print(f"训练集: {train_duration/3600:.2f} 小时")
    print(f"验证集: {val_duration/3600:.2f} 小时")
    print(f"测试集: {test_duration/3600:.2f} 小时")
    print(f"数据保存至: {train_dir}, {val_dir}, {test_dir}")
    print(f"日志: {log_dir}/data_split.log")

if __name__ == "__main__":
    split_dataset(
        sichuan_root="/scratch/s6070310/thesis/data/sichuan",
        scc_root="/scratch/s6070310/thesis/data/sc_dataset2",
        output_dir="/scratch/s6070310/thesis/data"
    )