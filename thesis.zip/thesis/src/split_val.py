import os
import logging
from pathlib import Path
import torch
import torchaudio
from torch.utils.data import Dataset, DataLoader
from transformers import Wav2Vec2ForCTC, Wav2Vec2Processor
from datasets import load_metric
import numpy as np
from typing import List, Tuple, Dict, Any
import json
from tqdm import tqdm

# 配置日志
log_dir = "/scratch/s6070310/thesis/log/model/test_primary_results"
os.makedirs(log_dir, exist_ok=True)
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s - %(levelname)s - %(message)s",
    filename=os.path.join(log_dir, "split_val_primary.log"),
    filemode="a",
)
console = logging.StreamHandler()
console.setLevel(logging.INFO)
logging.getLogger("").addHandler(console)

# 自定义测试数据集类
class TestSpeechDataset(Dataset):
    def __init__(self, data_dir: str, list_file: str, processor, filter_prefix=None):
        self.data_dir = Path(data_dir)
        self.processor = processor
        self.filter_prefix = filter_prefix  # 新增过滤前缀参数
        self.audio_files, self.transcriptions = self._load_transcriptions(list_file)
        
    def _load_transcriptions(self, list_file: str) -> Tuple[List[str], List[str]]:
        audio_files, transcriptions = [], []
        with open(list_file, "r", encoding="utf-8") as f:
            for line in f:
                parts = line.strip().split("\t")
                if len(parts) == 2:
                    audio_file = parts[0]
                    # 获取文件名（去掉路径前缀）
                    filename = os.path.basename(audio_file)
                    
                    # 如果指定了过滤前缀，只保留匹配的文件
                    if self.filter_prefix is None or filename.startswith(self.filter_prefix):
                        audio_files.append(audio_file)
                        transcriptions.append(parts[1])
        
        # 记录过滤结果
        if self.filter_prefix:
            logging.info(f"过滤前缀 '{self.filter_prefix}': 找到 {len(audio_files)} 个匹配文件")
        
        return audio_files, transcriptions
    
    def __len__(self):
        return len(self.audio_files)
    
    def __getitem__(self, idx):
        audio_path = self.data_dir / self.audio_files[idx]
        transcription = self.transcriptions[idx]
        
        # 加载音频
        waveform, sample_rate = torchaudio.load(audio_path)
        if sample_rate != 16000:
            resampler = torchaudio.transforms.Resample(sample_rate, 16000)
            waveform = resampler(waveform)
        if waveform.shape[0] > 1:
            waveform = waveform.mean(dim=0, keepdim=True)
        waveform = waveform.squeeze().numpy()
        
        return {
            "audio": waveform,
            "transcription": transcription,
            "audio_file": self.audio_files[idx]  # 添加音频文件名用于结果记录
        }

def collate_fn(batch):
    """数据整理函数"""
    # 提取音频数据
    input_features = [{"input_values": feature["audio"]} for feature in batch]
    
    # 处理音频数据
    processor = batch[0]["processor"] if "processor" in batch[0] else None
    if processor:
        processed_batch = processor.feature_extractor.pad(
            input_features,
            padding=True,
            return_tensors="pt",
        )
    else:
        # 手动padding
        max_length = max(len(f["input_values"]) for f in input_features)
        padded_inputs = []
        for f in input_features:
            input_values = f["input_values"]
            if len(input_values) < max_length:
                padding = np.zeros(max_length - len(input_values))
                input_values = np.concatenate([input_values, padding])
            padded_inputs.append(input_values)
        
        # 转换为numpy数组再转为tensor，避免性能警告
        padded_array = np.array(padded_inputs)
        processed_batch = {
            "input_values": torch.tensor(padded_array, dtype=torch.float32)
        }
    
    # 保留其他信息
    processed_batch["transcriptions"] = [feature["transcription"] for feature in batch]
    processed_batch["audio_files"] = [feature["audio_file"] for feature in batch]
    
    return processed_batch

def compute_metrics(predictions: List[str], references: List[str], processor) -> Dict[str, float]:
    """计算CER指标，参考原始训练代码的逻辑"""
    cer_metric = load_metric("cer")
    
    # 直接使用预测和参考文本计算CER
    cer = cer_metric.compute(predictions=predictions, references=references)
    
    return {"cer": cer}

def test_model_subset(model, processor, device, test_dataset, subset_name):
    """测试模型的子集"""
    logging.info(f"开始测试 {subset_name} 子集...")
    
    # 创建数据加载器
    test_dataloader = DataLoader(
        test_dataset,
        batch_size=8,  # 可以根据显存调整
        shuffle=False,
        num_workers=0,
        collate_fn=collate_fn
    )
    
    # 进行推理
    all_predictions = []
    all_references = []
    all_audio_files = []
    detailed_results = []
    
    with torch.no_grad():
        for batch_idx, batch in enumerate(tqdm(test_dataloader, desc=f"Testing {subset_name}")):
            # 将输入移到设备上
            input_values = batch["input_values"].to(device)
            transcriptions = batch["transcriptions"]
            audio_files = batch["audio_files"]
            
            # 模型推理
            try:
                logits = model(input_values).logits
                
                # 获取预测的token ids
                predicted_ids = torch.argmax(logits, dim=-1)
                
                # 解码预测结果
                predictions = processor.batch_decode(predicted_ids, skip_special_tokens=True)
                
                # 保存结果
                for i, (pred, ref, audio_file) in enumerate(zip(predictions, transcriptions, audio_files)):
                    all_predictions.append(pred)
                    all_references.append(ref)
                    all_audio_files.append(audio_file)
                    
                    # 计算单个样本的CER
                    cer_metric = load_metric("cer")
                    sample_cer = cer_metric.compute(predictions=[pred], references=[ref])
                    
                    detailed_results.append({
                        "audio_file": audio_file,
                        "reference": ref,
                        "prediction": pred,
                        "cer": sample_cer
                    })
                
            except Exception as e:
                logging.error(f"处理 {subset_name} 批次 {batch_idx} 时出错: {e}")
                continue
    
    # 计算总体指标
    overall_metrics = compute_metrics(all_predictions, all_references, processor)
    
    logging.info(f"{subset_name} 测试完成!")
    logging.info(f"{subset_name} CER: {overall_metrics['cer']:.4f}")
    
    return {
        "metrics": overall_metrics,
        "predictions": all_predictions,
        "references": all_references,
        "audio_files": all_audio_files,
        "detailed_results": detailed_results
    }

def test_model():
    # 模型路径
    model_path = "/scratch/s6070310/thesis/model/primary_model/final_model"
    
    # 测试数据路径
    test_dir = "/scratch/s6070310/thesis/data/val"
    test_list_file = os.path.join(test_dir, "list.txt")
    
    # 结果保存路径
    results_dir = "/scratch/s6070310/thesis/results/val_split_primary_model"
    os.makedirs(results_dir, exist_ok=True)
    
    # 检查模型是否存在
    if not os.path.exists(model_path):
        logging.error(f"模型路径不存在: {model_path}")
        return
    
    # 检查测试数据是否存在
    if not os.path.exists(test_list_file):
        logging.error(f"测试数据列表文件不存在: {test_list_file}")
        return
    
    # 加载模型和处理器
    logging.info("加载模型和处理器...")
    try:
        model = Wav2Vec2ForCTC.from_pretrained(model_path)
        processor = Wav2Vec2Processor.from_pretrained(model_path)
        
        # 设置设备
        device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
        model.to(device)
        model.eval()
        
        logging.info(f"模型加载成功，使用设备: {device}")
    except Exception as e:
        logging.error(f"加载模型失败: {e}")
        return
    
    # 创建不同的数据集
    logging.info("创建数据集...")
    
    # 完整数据集
    full_dataset = TestSpeechDataset(test_dir, test_list_file, processor)
    logging.info(f"完整测试集大小: {len(full_dataset)}")
    
    # val_G数据集
    val_g_dataset = TestSpeechDataset(test_dir, test_list_file, processor, filter_prefix="val_G")
    
    # val_SCC数据集
    val_scc_dataset = TestSpeechDataset(test_dir, test_list_file, processor, filter_prefix="val_SCC")
    
    # 存储所有结果
    all_results = {}
    
    # 测试完整数据集
    logging.info("="*60)
    logging.info("测试完整数据集")
    logging.info("="*60)
    full_results = test_model_subset(model, processor, device, full_dataset, "Full")
    all_results["full"] = full_results
    
    # 测试val_G数据集
    if len(val_g_dataset) > 0:
        logging.info("="*60)
        logging.info("测试val_G数据集")
        logging.info("="*60)
        val_g_results = test_model_subset(model, processor, device, val_g_dataset, "val_G")
        all_results["val_G"] = val_g_results
    else:
        logging.warning("val_G数据集为空，跳过测试")
        all_results["val_G"] = None
    
    # 测试val_SCC数据集
    if len(val_scc_dataset) > 0:
        logging.info("="*60)
        logging.info("测试val_SCC数据集")
        logging.info("="*60)
        val_scc_results = test_model_subset(model, processor, device, val_scc_dataset, "val_SCC")
        all_results["val_SCC"] = val_scc_results
    else:
        logging.warning("val_SCC数据集为空，跳过测试")
        all_results["val_SCC"] = None
    
    # 输出最终汇总结果
    logging.info("="*60)
    logging.info("最终测试结果汇总")
    logging.info("="*60)
    
    print("\n" + "="*60)
    print("最终测试结果汇总")
    print("="*60)
    
    for subset_name, results in all_results.items():
        if results is not None:
            cer = results["metrics"]["cer"]
            sample_count = len(results["predictions"])
            logging.info(f"{subset_name.upper()}: CER = {cer:.4f}, 样本数 = {sample_count}")
            print(f"{subset_name.upper()}: CER = {cer:.4f}, 样本数 = {sample_count}")
        else:
            logging.info(f"{subset_name.upper()}: 无数据")
            print(f"{subset_name.upper()}: 无数据")
    
    # 保存详细结果
    results_file = os.path.join(results_dir, "test_MD_classified_results.json")
    
    # 准备保存的数据（简化版本，避免文件过大）
    save_data = {}
    for subset_name, results in all_results.items():
        if results is not None:
            save_data[subset_name] = {
                "overall_metrics": results["metrics"],
                "total_samples": len(results["predictions"]),
                "detailed_results": results["detailed_results"][:100]  # 只保存前100个详细结果
            }
        else:
            save_data[subset_name] = None
    
    with open(results_file, "w", encoding="utf-8") as f:
        json.dump(save_data, f, ensure_ascii=False, indent=2)
    
    logging.info(f"详细结果已保存至: {results_file}")
    
    # 保存每个子集的预测结果
    for subset_name, results in all_results.items():
        if results is not None:
            predictions_file = os.path.join(results_dir, f"predictions_{subset_name}.txt")
            with open(predictions_file, "w", encoding="utf-8") as f:
                for audio_file, ref, pred in zip(results["audio_files"], results["references"], results["predictions"]):
                    f.write(f"{audio_file}\t{ref}\t{pred}\n")
            logging.info(f"{subset_name} 预测结果已保存至: {predictions_file}")
    
    # 错误分析
    logging.info("="*60)
    logging.info("错误分析")
    logging.info("="*60)
    
    for subset_name, results in all_results.items():
        if results is not None:
            detailed_results = results["detailed_results"]
            high_error_samples = [r for r in detailed_results if r["cer"] > 0.5]
            low_error_samples = [r for r in detailed_results if r["cer"] < 0.1]
            
            logging.info(f"{subset_name} - 高错误样本数量 (CER > 0.5): {len(high_error_samples)}")
            logging.info(f"{subset_name} - 低错误样本数量 (CER < 0.1): {len(low_error_samples)}")
            
            # 保存错误分析
            error_analysis = {
                "high_error_samples": high_error_samples[:20],
                "low_error_samples": low_error_samples[:20],
                "error_distribution": {
                    "cer_0_to_0.1": len([r for r in detailed_results if 0 <= r["cer"] < 0.1]),
                    "cer_0.1_to_0.3": len([r for r in detailed_results if 0.1 <= r["cer"] < 0.3]),
                    "cer_0.3_to_0.5": len([r for r in detailed_results if 0.3 <= r["cer"] < 0.5]),
                    "cer_0.5_to_1.0": len([r for r in detailed_results if 0.5 <= r["cer"] <= 1.0])
                }
            }
            
            error_analysis_file = os.path.join(results_dir, f"error_analysis_{subset_name}.json")
            with open(error_analysis_file, "w", encoding="utf-8") as f:
                json.dump(error_analysis, f, ensure_ascii=False, indent=2)
    
    return all_results

if __name__ == "__main__":
    try:
        all_results = test_model()
        if all_results:
            print(f"\n=== 最终测试结果 ===")
            for subset_name, results in all_results.items():
                if results is not None:
                    print(f"{subset_name.upper()}: CER = {results['metrics']['cer']:.4f}")
                else:
                    print(f"{subset_name.upper()}: 无数据")
    except Exception as e:
        logging.error(f"测试过程中出现错误: {e}")
        raise