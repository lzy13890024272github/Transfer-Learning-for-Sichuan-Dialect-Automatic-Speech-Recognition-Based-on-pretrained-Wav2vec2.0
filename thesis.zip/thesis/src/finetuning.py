import os
import logging
from pathlib import Path
import torch
from torch.utils.data import Dataset, DataLoader
import torchaudio
from transformers import Wav2Vec2ForCTC, Wav2Vec2Processor, Trainer, TrainingArguments
import numpy as np
from typing import Dict, List, Tuple
# from datasets import load_metric
import evaluate

# 配置日志
def setup_logging(model_name: str, log_dir: str = "/scratch/s6070310/thesis/log/model"):
    log_path = Path(log_dir) / model_name
    log_path.mkdir(parents=True, exist_ok=True)
    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s - %(levelname)s - %(message)s",
        handlers=[
            logging.FileHandler(log_path / "train.log", mode="w"),
            logging.StreamHandler()
        ]
    )
    return logging.getLogger()

# 自定义数据集
class SichuanASRDataset(Dataset):
    def __init__(self, data_dir: str, list_file: str, processor: Wav2Vec2Processor):
        self.data_dir = Path(data_dir)
        self.processor = processor
        self.audio_files = []
        self.transcriptions = []

        with open(list_file, "r", encoding="utf-8") as f:
            for line in f:
                parts = line.strip().split("\t")
                if len(parts) == 2:
                    audio_path = parts[0].split("/")[-1]
                    transcription = parts[1]
                    self.audio_files.append(audio_path)
                    self.transcriptions.append(transcription)

    def __len__(self):
        return len(self.audio_files)

    def __getitem__(self, idx):
        audio_path = self.data_dir / self.audio_files[idx]
        transcription = self.transcriptions[idx]

        # 加载音频
        waveform, sample_rate = torchaudio.load(audio_path)
        if sample_rate != 16000:
            waveform = torchaudio.transforms.Resample(sample_rate, 16000)(waveform)
        audio = waveform.squeeze().numpy()

        # 数据增强（仅用于训练）
        if self.data_dir.name == "train":
            # 音量扰动
            if np.random.rand() < 0.5:
                gain = np.random.uniform(0.8, 1.2)
                audio = audio * gain
            # 时间拉伸
            if np.random.rand() < 0.5:
                speed = np.random.uniform(0.9, 1.1)
                audio = torchaudio.transforms.Speed(speed_factor=speed)(waveform)[0].squeeze().numpy()

        # 处理音频和文本
        inputs = self.processor(audio, sampling_rate=16000, return_tensors="pt", padding=True)
        labels = self.processor(text=transcription, return_tensors="pt").input_ids

        return {
            "input_values": inputs.input_values.squeeze(),
            "labels": labels.squeeze(),
            "input_ids": labels.squeeze()
        }

# 计算 CER
#cer_metric = load_metric("cer")
cer_metric = evaluate.load("cer", trust_remote_code=True)
def compute_metrics(pred):
    pred_logits = pred.predictions
    pred_ids = np.argmax(pred_logits, axis=-1)
    pred_str = processor.batch_decode(pred_ids)
    label_str = processor.batch_decode(pred.label_ids, group_tokens=False)
    cer = cer_metric.compute(predictions=pred_str, references=label_str)
    return {"cer": cer}

# 训练函数
def train_model(
    model_name: str,
    model_type: str,
    train_dir: str,
    val_dir: str,
    train_list: str,
    val_list: str,
    output_dir: str,
    use_augmentation: bool = False
):
    logger = setup_logging(model_name)
    logger.info(f"Starting training for {model_name} with model {model_type}")

    # 加载模型和处理器
    if model_type == "chinese":
        model_path = "jonatasgrosman/wav2vec2-large-xlsr-53-chinese-zh-cn"
    else:
        model_path = "facebook/wav2vec2-large-xlsr-53"
    
    processor = Wav2Vec2Processor.from_pretrained(model_path)
    model = Wav2Vec2ForCTC.from_pretrained(model_path)

    # 准备数据集
    train_dataset = SichuanASRDataset(train_dir, train_list, processor)
    val_dataset = SichuanASRDataset(val_dir, val_list, processor)

    # 配置训练参数
    training_args = TrainingArguments(
        output_dir=output_dir,
        group_by_length=True,
        per_device_train_batch_size=16,
        per_device_eval_batch_size=16,
        evaluation_strategy="epoch",
        save_strategy="epoch",
        save_steps=10,  # 每 10 个 epoch 保存
        num_train_epochs=20,
        learning_rate=5e-5,
        logging_dir=output_dir / "logs",
        logging_steps=10,
        load_best_model_at_end=True,
        metric_for_best_model="cer",
        greater_is_better=False,
        save_total_limit=2
    )

    trainer = Trainer(
        model=model,
        args=training_args,
        train_dataset=train_dataset,
        eval_dataset=val_dataset,
        compute_metrics=compute_metrics,
        data_collator=lambda data: {
            "input_values": torch.stack([d["input_values"] for d in data]),
            "labels": torch.stack([d["labels"] for d in data])
        }
    )

    # 训练
    trainer.train()

    # 保存最终模型
    final_model_path = output_dir / "final_model"
    trainer.save_model(final_model_path)
    processor.save_pretrained(final_model_path)
    logger.info(f"Final model saved to {final_model_path}")

# 主函数
if __name__ == "__main__":
    base_dir = "/scratch/s6070310/thesis"
    models = [
#        {
#            "name": "baseline_model",
#            "type": "chinese",
#            "train_dir": "/scratch/s6070310/thesis/data/train_unfiltered/wavs",
#            "train_list": "/scratch/s6070310/thesis/data/train_unfiltered/list.txt",
#            "use_augmentation": False
#        },
        {
            "name": "primary_model",
            "type": "chinese",
            "train_dir": "/scratch/s6070310/thesis/data/train/wavs",
            "train_list": "/scratch/s6070310/thesis/data/train/list.txt",
            "use_augmentation": True
        }
#        {
#            "name": "magicdata_only_model",
#            "type": "chinese",
#            "train_dir": "/scratch/s6070310/thesis/data/train_magicdata/wavs",
#            "train_list": "/scratch/s6070310/thesis/data/train_magicdata/list.txt",
#            "use_augmentation": False
#        },
#        {
#            "name": "base_model",
#            "type": "base",
#            "train_dir": "/scratch/s6070310/thesis/data/train/wavs",
#            "train_list": "/scratch/s6070310/thesis/data/train/list.txt",
#            "use_augmentation": True
#        }
    ]

    for model_config in models:
        output_dir = Path(base_dir) / "model" / model_config["name"]
        output_dir.mkdir(parents=True, exist_ok=True)
        train_model(
            model_name=model_config["name"],
            model_type=model_config["type"],
            train_dir=model_config["train_dir"],
            val_dir="/scratch/s6070310/thesis/data/val/wavs",
            train_list=model_config["train_list"],
            val_list="/scratch/s6070310/thesis/data/val/list.txt",
            output_dir=output_dir,
            use_augmentation=model_config["use_augmentation"]
        )