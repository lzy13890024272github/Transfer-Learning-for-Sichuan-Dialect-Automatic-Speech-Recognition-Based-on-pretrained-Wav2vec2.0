import os
import logging
from pathlib import Path
import torch
import torchaudio
from torch.utils.data import Dataset, DataLoader
from transformers import Wav2Vec2ForCTC, Wav2Vec2Processor
from datasets import load_metric
import numpy as np
from typing import List, Tuple, Dict, Any
import json
from tqdm import tqdm

# 配置日志
log_dir = "/scratch/s6070310/thesis/log/model/test_MD_results"
os.makedirs(log_dir, exist_ok=True)
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s - %(levelname)s - %(message)s",
    filename=os.path.join(log_dir, "val_MD.log"),
    filemode="a",
)
console = logging.StreamHandler()
console.setLevel(logging.INFO)
logging.getLogger("").addHandler(console)

# 自定义测试数据集类
class TestSpeechDataset(Dataset):
    def __init__(self, data_dir: str, list_file: str, processor):
        self.data_dir = Path(data_dir)
        self.processor = processor
        self.audio_files, self.transcriptions = self._load_transcriptions(list_file)
        
    def _load_transcriptions(self, list_file: str) -> Tuple[List[str], List[str]]:
        audio_files, transcriptions = [], []
        with open(list_file, "r", encoding="utf-8") as f:
            for line in f:
                parts = line.strip().split("\t")
                if len(parts) == 2:
                    audio_files.append(parts[0])
                    transcriptions.append(parts[1])
        return audio_files, transcriptions
    
    def __len__(self):
        return len(self.audio_files)
    
    def __getitem__(self, idx):
        audio_path = self.data_dir / self.audio_files[idx]
        transcription = self.transcriptions[idx]
        
        # 加载音频
        waveform, sample_rate = torchaudio.load(audio_path)
        if sample_rate != 16000:
            resampler = torchaudio.transforms.Resample(sample_rate, 16000)
            waveform = resampler(waveform)
        if waveform.shape[0] > 1:
            waveform = waveform.mean(dim=0, keepdim=True)
        waveform = waveform.squeeze().numpy()
        
        return {
            "audio": waveform,
            "transcription": transcription,
            "audio_file": self.audio_files[idx]  # 添加音频文件名用于结果记录
        }

def collate_fn(batch):
    """数据整理函数"""
    # 提取音频数据
    input_features = [{"input_values": feature["audio"]} for feature in batch]
    
    # 处理音频数据
    processor = batch[0]["processor"] if "processor" in batch[0] else None
    if processor:
        processed_batch = processor.feature_extractor.pad(
            input_features,
            padding=True,
            return_tensors="pt",
        )
    else:
        # 手动padding
        max_length = max(len(f["input_values"]) for f in input_features)
        padded_inputs = []
        for f in input_features:
            input_values = f["input_values"]
            if len(input_values) < max_length:
                padding = np.zeros(max_length - len(input_values))
                input_values = np.concatenate([input_values, padding])
            padded_inputs.append(input_values)
        
        # 转换为numpy数组再转为tensor，避免性能警告
        padded_array = np.array(padded_inputs)
        processed_batch = {
            "input_values": torch.tensor(padded_array, dtype=torch.float32)
        }
    
    # 保留其他信息
    processed_batch["transcriptions"] = [feature["transcription"] for feature in batch]
    processed_batch["audio_files"] = [feature["audio_file"] for feature in batch]
    
    return processed_batch

def compute_metrics(predictions: List[str], references: List[str], processor) -> Dict[str, float]:
    """计算CER指标，参考原始训练代码的逻辑"""
    cer_metric = load_metric("cer")
    
    # 直接使用预测和参考文本计算CER
    cer = cer_metric.compute(predictions=predictions, references=references)
    
    return {"cer": cer}

def test_model():
    # 模型路径
    model_path = "/scratch/s6070310/thesis/model/MD_model/final_model"
    
    # 测试数据路径
    test_dir = "/scratch/s6070310/thesis/data/val"
    test_list_file = os.path.join(test_dir, "list.txt")
    
    # 结果保存路径
    results_dir = "/scratch/s6070310/thesis/results/val_MD_model"
    os.makedirs(results_dir, exist_ok=True)
    
    # 检查模型是否存在
    if not os.path.exists(model_path):
        logging.error(f"模型路径不存在: {model_path}")
        return
    
    # 检查测试数据是否存在
    if not os.path.exists(test_list_file):
        logging.error(f"测试数据列表文件不存在: {test_list_file}")
        return
    
    # 加载模型和处理器
    logging.info("加载模型和处理器...")
    try:
        model = Wav2Vec2ForCTC.from_pretrained(model_path)
        processor = Wav2Vec2Processor.from_pretrained(model_path)
        
        # 设置设备
        device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
        model.to(device)
        model.eval()
        
        logging.info(f"模型加载成功，使用设备: {device}")
    except Exception as e:
        logging.error(f"加载模型失败: {e}")
        return
    
    # 加载测试数据集
    logging.info("加载测试数据集...")
    test_dataset = TestSpeechDataset(test_dir, test_list_file, processor)
    logging.info(f"测试集大小: {len(test_dataset)}")
    
    # 创建数据加载器
    test_dataloader = DataLoader(
        test_dataset,
        batch_size=8,  # 可以根据显存调整
        shuffle=False,
        num_workers=0,
        collate_fn=collate_fn
    )
    
    # 进行推理
    logging.info("开始测试...")
    all_predictions = []
    all_references = []
    all_audio_files = []
    detailed_results = []
    
    with torch.no_grad():
        for batch_idx, batch in enumerate(tqdm(test_dataloader, desc="Testing")):
            # 将输入移到设备上
            input_values = batch["input_values"].to(device)
            transcriptions = batch["transcriptions"]
            audio_files = batch["audio_files"]
            
            # 模型推理
            try:
                logits = model(input_values).logits
                
                # 获取预测的token ids
                predicted_ids = torch.argmax(logits, dim=-1)
                
                # 解码预测结果
                predictions = processor.batch_decode(predicted_ids, skip_special_tokens=True)
                
                # 保存结果
                for i, (pred, ref, audio_file) in enumerate(zip(predictions, transcriptions, audio_files)):
                    all_predictions.append(pred)
                    all_references.append(ref)
                    all_audio_files.append(audio_file)
                    
                    # 计算单个样本的CER
                    cer_metric = load_metric("cer")
                    sample_cer = cer_metric.compute(predictions=[pred], references=[ref])
                    
                    detailed_results.append({
                        "audio_file": audio_file,
                        "reference": ref,
                        "prediction": pred,
                        "cer": sample_cer
                    })
                
            except Exception as e:
                logging.error(f"处理批次 {batch_idx} 时出错: {e}")
                continue
    
    # 计算总体指标
    logging.info("计算总体指标...")
    overall_metrics = compute_metrics(all_predictions, all_references, processor)
    
    logging.info(f"测试完成!")
    logging.info(f"总体 CER: {overall_metrics['cer']:.4f}")
    
    # 保存详细结果
    results_file = os.path.join(results_dir, "test_MD2_results.json")
    results_data = {
        "overall_metrics": overall_metrics,
        "total_samples": len(all_predictions),
        "detailed_results": detailed_results
    }
    
    with open(results_file, "w", encoding="utf-8") as f:
        json.dump(results_data, f, ensure_ascii=False, indent=2)
    
    logging.info(f"详细结果已保存至: {results_file}")
    
    # 保存预测结果为文本文件
    predictions_file = os.path.join(results_dir, "predictions.txt")
    with open(predictions_file, "w", encoding="utf-8") as f:
        for audio_file, ref, pred in zip(all_audio_files, all_references, all_predictions):
            f.write(f"{audio_file}\t{ref}\t{pred}\n")
    
    logging.info(f"预测结果已保存至: {predictions_file}")
    
    # 分析错误情况
    logging.info("分析错误情况...")
    high_error_samples = [r for r in detailed_results if r["cer"] > 0.5]
    low_error_samples = [r for r in detailed_results if r["cer"] < 0.1]
    
    logging.info(f"高错误样本数量 (CER > 0.5): {len(high_error_samples)}")
    logging.info(f"低错误样本数量 (CER < 0.1): {len(low_error_samples)}")
    
    # 保存错误分析
    error_analysis = {
        "high_error_samples": high_error_samples[:20],  # 保存前20个高错误样本
        "low_error_samples": low_error_samples[:20],   # 保存前20个低错误样本
        "error_distribution": {
            "cer_0_to_0.1": len([r for r in detailed_results if 0 <= r["cer"] < 0.1]),
            "cer_0.1_to_0.3": len([r for r in detailed_results if 0.1 <= r["cer"] < 0.3]),
            "cer_0.3_to_0.5": len([r for r in detailed_results if 0.3 <= r["cer"] < 0.5]),
            "cer_0.5_to_1.0": len([r for r in detailed_results if 0.5 <= r["cer"] <= 1.0])
        }
    }
    
    error_analysis_file = os.path.join(results_dir, "error_analysis.json")
    with open(error_analysis_file, "w", encoding="utf-8") as f:
        json.dump(error_analysis, f, ensure_ascii=False, indent=2)
    
    logging.info(f"错误分析已保存至: {error_analysis_file}")
    
    return overall_metrics

if __name__ == "__main__":
    try:
        metrics = test_model()
        if metrics:
            print(f"\n=== 测试结果 ===")
            print(f"CER: {metrics['cer']:.4f}")
    except Exception as e:
        logging.error(f"测试过程中出现错误: {e}")
        raise