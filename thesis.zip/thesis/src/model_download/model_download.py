from transformers import Wav2Vec2ForCTC, Wav2Vec2Processor, Wav2Vec2CTCTokenizer
import os

# 设置目标保存路径
save_directory = "thesis/model/original_model"
os.makedirs(save_directory, exist_ok=True)

# 下载并保存第一个模型
model_name_1 = "/scratch/s6070310/jonatasgrosman/wav2vec2-large-xlsr-53-chinese-zh-cn"
try:
    model_1 = Wav2Vec2ForCTC.from_pretrained(model_name_1)
    processor_1 = Wav2Vec2Processor.from_pretrained(model_name_1)
    model_1.save_pretrained(os.path.join(save_directory, "wav2vec2-large-xlsr-53-chinese-zh-cn"))
    processor_1.save_pretrained(os.path.join(save_directory, "wav2vec2-large-xlsr-53-chinese-zh-cn"))
    print(f"模型 {model_name_1} 下载并保存成功！")
except Exception as e:
    print(f"下载 {model_name_1} 失败: {e}")

# 下载并保存第二个模型（仅模型权重和配置，处理tokenizer问题）
model_name_2 = "facebook/wav2vec2-large-xlsr-53"
try:
    model_2 = Wav2Vec2ForCTC.from_pretrained(model_name_2)
    model_2.save_pretrained(os.path.join(save_directory, "wav2vec2-large-xlsr-53"))
    print(f"模型权重 {model_name_2} 下载并保存成功！")
    
    # 尝试加载处理器，若失败则创建默认tokenizer
    try:
        processor_2 = Wav2Vec2Processor.from_pretrained(model_name_2)
        processor_2.save_pretrained(os.path.join(save_directory, "wav2vec2-large-xlsr-53"))
        print(f"处理器 {model_name_2} 下载并保存成功！")
    except Exception as e:
        print(f"加载 {model_name_2} 的处理器失败: {e}")
        print("创建默认 Wav2Vec2CTCTokenizer 作为备用...")
        # 使用基础模型的tokenizer作为备用
        tokenizer = Wav2Vec2CTCTokenizer.from_pretrained(
            "facebook/wav2vec2-base-960h",
            do_lower_case=False,
            word_delimiter_token="|"
        )
        processor_2 = Wav2Vec2Processor.from_pretrained(
            "facebook/wav2vec2-base-960h",
            tokenizer=tokenizer
        )
        processor_2.save_pretrained(os.path.join(save_directory, "wav2vec2-large-xlsr-53"))
        print(f"备用处理器 {model_name_2} 创建并保存成功！")
except Exception as e:
    print(f"下载 {model_name_2} 失败: {e}")

print("所有操作完成！")