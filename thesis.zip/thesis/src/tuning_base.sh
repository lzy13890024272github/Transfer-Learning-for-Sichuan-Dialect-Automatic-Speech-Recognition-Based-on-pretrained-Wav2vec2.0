#!/bin/bash
#SBATCH --time=24:00:00
#SBATCH --nodes=1
#SBATCH --gpus-per-node=a100
#SBATCH --mem=64G
#SBATCH --job-name=base_model_training
#SBATCH --output=/scratch/s6070310/thesis/log/model/base_model/base_model_training_%j.out
#SBATCH --error=/scratch/s6070310/thesis/log/model/base_model/base_model_training_%j.err

# 清理模块环境并加载CUDA
module purge
module load CUDA/11.8.0

# 激活虚拟环境（如果有的话）
source /scratch/s6070310/fastspeech2_env/bin/activate

# 切换到工作目录
cd /scratch/s6070310/thesis/src/base_model

# 运行训练脚本
python tuning_base.py