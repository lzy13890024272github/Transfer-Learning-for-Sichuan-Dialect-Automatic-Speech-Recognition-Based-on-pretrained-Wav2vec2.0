
import logging
import torch
import torchaudio
import numpy as np
from transformers import AutoProcessor, AutoModelForCTC
from evaluate import load as load_metric
from datetime import datetime
import os
from typing import List, Tuple, Optional

# 生成带时间戳的日志文件名
log_dir = "/scratch/s6070310/thesis/log"
os.makedirs(log_dir, exist_ok=True)
log_file = os.path.join(log_dir, f"cer_evaluation_{datetime.now().strftime('%Y%m%d_%H%M%S')}.log")

# 配置日志
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s - %(levelname)s - %(message)s",
    filename=log_file,
)

# 加载模型和处理器
MODEL_NAME = "TencentGameMate/chinese-hubert-base"

processor = AutoProcessor.from_pretrained(MODEL_NAME)
model = AutoModelForCTC.from_pretrained(MODEL_NAME).to("cuda" if torch.cuda.is_available() else "cpu")

# 加载 CER 评估指标
cer_metric = load_metric("cer")

def read_transcriptions(file_path: str) -> List[Tuple[str, str, str]]:
    """从 list.txt 中读取转录内容"""
    transcriptions = []
    try:
        with open(file_path, "r", encoding="utf-8") as f:
            for line in f:
                parts = line.strip().split("\t")
                if len(parts) >= 5:
                    audio_file, group, transcription = parts[1], parts[2], parts[4]
                    transcriptions.append((audio_file, group, transcription))
        logging.info(f"加载了 {len(transcriptions)} 个转录条目")
        return transcriptions
    except Exception as e:
        logging.error(f"读取 {file_path} 出错: {e}")
        return []

def load_audio(audio_path: str, target_sr: int = 16000) -> Optional[np.ndarray]:
    """加载并重采样音频到 16kHz"""
    try:
        waveform, sample_rate = torchaudio.load(audio_path)
        if sample_rate != target_sr:
            resampler = torchaudio.transforms.Resample(sample_rate, target_sr)
            waveform = resampler(waveform)
        if waveform.shape[0] > 1:
            waveform = waveform.mean(dim=0, keepdim=True)
        return waveform.squeeze().numpy()
    except Exception as e:
        logging.error(f"加载音频 {audio_path} 出错: {e}")
        return None

def transcribe_audio(audio: np.ndarray) -> str:
    """使用 HuBERT 模型进行音频转录"""
    try:
        inputs = processor(audio, sampling_rate=16000, return_tensors="pt", padding=True)
        with torch.no_grad():
            logits = model(
                inputs.input_values.to(model.device),
                attention_mask=inputs.attention_mask.to(model.device)
            ).logits
        predicted_ids = torch.argmax(logits, dim=-1)
        transcription = processor.batch_decode(predicted_ids)[0]
        return transcription
    except Exception as e:
        logging.error(f"转录音频出错: {e}")
        return ""

def evaluate_cer(audio_dir: str, transcriptions: List[Tuple[str, str, str]]) -> float:
    """评估数据集的 CER"""
    predictions = []
    references = []
    for audio_file, group, ref_text in transcriptions:
        audio_path = os.path.join(audio_dir, group, audio_file)
        if not os.path.exists(audio_path):
            logging.warning(f"音频文件未找到: {audio_path}")
            continue
        audio = load_audio(audio_path)
        if audio is None:
            continue
        pred_text = transcribe_audio(audio)
        if not pred_text:
            continue
        predictions.append(pred_text)
        references.append(ref_text)
        logging.info(f"处理文件 {audio_file}: 预测='{pred_text}', 参考='{ref_text}'")
    
    if not predictions:
        logging.error("没有处理任何有效音频文件")
        return float("inf")
    
    cer = cer_metric.compute(predictions=predictions, references=references)
    return cer

def main():
    # 路径设置
    audio_dir = "/scratch/s6070310/thesis/data/sichuan/wav"
    transcription_file = "/scratch/s6070310/thesis/data/sichuan/list.txt"
    
    # 记录数据集信息
    dataset_name = "四川话语音数据集 (G0001 和 G1108)"
    logging.info(f"评估数据集: {dataset_name}")
    logging.info(f"模型: {MODEL_NAME}")
    logging.info(f"音频目录: {audio_dir}")
    logging.info(f"转录文件: {transcription_file}")
    
    # 读取转录
    transcriptions = read_transcriptions(transcription_file)
    if not transcriptions:
        print("无法加载转录文件，退出")
        return
    
    # 评估 CER
    cer = evaluate_cer(audio_dir, transcriptions)
    
    # 记录结果
    logging.info(f"CER: {cer:.4f}")
    logging.info("评估完成")
    
    # 打印摘要
    print(f"数据集: {dataset_name}")
    print(f"模型: {MODEL_NAME}")
    print(f"CER: {cer:.4f}")
    print(f"查看 {log_file} 获取详细日志")

if __name__ == "__main__":
    main()