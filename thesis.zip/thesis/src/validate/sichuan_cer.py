import logging
import os
import torch
import torchaudio
import numpy as np
from transformers import Wav2Vec2Processor, Wav2Vec2ForCTC
from evaluate import load as load_metric
from pathlib import Path
from typing import List, Tuple, Optional

# Ensure log directory exists
log_dir = "/scratch/s6070310/thesis/log"
os.makedirs(log_dir, exist_ok=True)
log_file = os.path.join(log_dir, "cer_evaluation.log")

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s - %(levelname)s - %(message)s",
    filename=log_file,
)

# Load model and processor
MODEL_NAME = "jonatasgrosman/wav2vec2-large-xlsr-53-chinese-zh-cn"
processor = Wav2Vec2Processor.from_pretrained(MODEL_NAME)
model = Wav2Vec2ForCTC.from_pretrained(MODEL_NAME).to("cuda" if torch.cuda.is_available() else "cpu")

# Load CER metric
cer_metric = load_metric("cer")

def read_transcriptions(file_path: str) -> List[Tuple[str, str, str]]:
    """Read transcriptions from list.txt."""
    transcriptions = []
    with open(file_path, "r", encoding="utf-8") as f:
        for line in f:
            parts = line.strip().split("\t")
            if len(parts) >= 5:
                audio_file, group, transcription = parts[1], parts[2], parts[4]
                transcriptions.append((audio_file, group, transcription))
    return transcriptions

def load_audio(audio_path: str, target_sr: int = 16000) -> Optional[np.ndarray]:
    """Load and resample audio to 16kHz."""
    try:
        waveform, sample_rate = torchaudio.load(audio_path)
        if sample_rate != target_sr:
            resampler = torchaudio.transforms.Resample(sample_rate, target_sr)
            waveform = resampler(waveform)
        if waveform.shape[0] > 1:
            waveform = waveform.mean(dim=0, keepdim=True)
        return waveform.squeeze().numpy()
    except Exception as e:
        logging.error(f"Error loading {audio_path}: {e}")
        return None

def transcribe_audio(audio: np.ndarray) -> str:
    """Transcribe audio using Wav2Vec2 model."""
    inputs = processor(audio, sampling_rate=16000, return_tensors="pt", padding=True)
    with torch.no_grad():
        logits = model(
            inputs.input_values.to(model.device),
            attention_mask=inputs.attention_mask.to(model.device)
        ).logits
    predicted_ids = torch.argmax(logits, dim=-1)
    transcription = processor.batch_decode(predicted_ids)[0]
    return transcription

def evaluate_cer(audio_dir: str, transcriptions: List[Tuple[str, str, str]]) -> float:
    """Evaluate CER for the dataset."""
    predictions = []
    references = []
    for audio_file, group, ref_text in transcriptions:
        audio_path = os.path.join(audio_dir, group, audio_file)
        if not os.path.exists(audio_path):
            logging.warning(f"Audio file not found: {audio_path}")
            continue
        audio = load_audio(audio_path)
        if audio is None:
            continue
        pred_text = transcribe_audio(audio)
        predictions.append(pred_text)
        references.append(ref_text)
        logging.info(f"Processed {audio_file}: Predicted='{pred_text}', Reference='{ref_text}'")
    
    if not predictions:
        logging.error("No valid audio files processed.")
        return float("inf")
    
    cer = cer_metric.compute(predictions=predictions, references=references)
    return cer

def main():
    # Paths
    audio_dir = "/scratch/s6070310/thesis/data/sichuan/wav"
    transcription_file = "/scratch/s6070310/thesis/data/sichuan/list.txt"
    
    # Log dataset info
    dataset_name = "Sichuanese ASR Dataset (G0001 and G1108)"
    logging.info(f"Evaluating dataset: {dataset_name}")
    logging.info(f"Model: {MODEL_NAME}")
    logging.info(f"Audio directory: {audio_dir}")
    logging.info(f"Transcription file: {transcription_file}")
    
    # Read transcriptions
    transcriptions = read_transcriptions(transcription_file)
    logging.info(f"Loaded {len(transcriptions)} transcriptions")
    
    # Evaluate CER
    cer = evaluate_cer(audio_dir, transcriptions)
    
    # Log results
    logging.info(f"CER: {cer:.4f}")
    logging.info("Evaluation completed.")
    
    # Print summary
    print(f"Dataset: {dataset_name}")
    print(f"Model: {MODEL_NAME}")
    print(f"CER: {cer:.4f}")
    print(f"Check {log_file} for detailed logs.")

if __name__ == "__main__":
    main()