import torchaudio
def resample_audio(input_path, output_path, target_sr=16000):
    waveform, sr = torchaudio.load(input_path)
    if sr != target_sr:
        waveform = torchaudio.transforms.Resample(sr, target_sr)(waveform)
    torchaudio.save(output_path, waveform, target_sr)
# 示例：转换单个文件
resample_audio("input.wav", "output_16khz.wav")