import os
import logging
from pathlib import Path
import torch
import torchaudio
from torch.utils.data import Dataset, DataLoader
from transformers import Wav2Vec2ForCTC, Wav2Vec2Processor, Trainer, TrainingArguments
from datasets import load_metric
import numpy as np
from typing import List, Tuple, Dict, Any
import math
from dataclasses import dataclass

# 配置日志
log_dir = "/scratch/s6070310/thesis/log/model/primary_model"
os.makedirs(log_dir, exist_ok=True)
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s - %(levelname)s - %(message)s",
    filename=os.path.join(log_dir, "finetune.log"),
    filemode="a",
)
console = logging.StreamHandler()
console.setLevel(logging.INFO)
logging.getLogger("").addHandler(console)

# 自定义数据集类
class SpeechDataset(Dataset):
    def __init__(self, data_dir: str, list_file: str, processor):
        self.data_dir = Path(data_dir)
        self.processor = processor
        self.audio_files, self.transcriptions = self._load_transcriptions(list_file)
        
    def _load_transcriptions(self, list_file: str) -> Tuple[List[str], List[str]]:
        audio_files, transcriptions = [], []
        with open(list_file, "r", encoding="utf-8") as f:
            for line in f:
                parts = line.strip().split("\t")
                if len(parts) == 2:
                    audio_files.append(parts[0])
                    transcriptions.append(parts[1])
        return audio_files, transcriptions
    
    def __len__(self):
        return len(self.audio_files)
    
    def __getitem__(self, idx):
        audio_path = self.data_dir / self.audio_files[idx]
        transcription = self.transcriptions[idx]
        
        # 加载音频
        waveform, sample_rate = torchaudio.load(audio_path)
        if sample_rate != 16000:
            resampler = torchaudio.transforms.Resample(sample_rate, 16000)
            waveform = resampler(waveform)
        if waveform.shape[0] > 1:
            waveform = waveform.mean(dim=0, keepdim=True)
        waveform = waveform.squeeze().numpy()
        
        return {
            "audio": waveform,  # 返回原始音频数据
            "transcription": transcription
        }

@dataclass
class DataCollatorCTCWithPadding:
    """
    专为Wav2Vec2 CTC训练设计的数据整理器
    """
    processor: Wav2Vec2Processor
    padding: bool = True
    
    def __call__(self, features: List[Dict[str, Any]]) -> Dict[str, torch.Tensor]:
        # 提取音频数据
        input_features = [{"input_values": feature["audio"]} for feature in features]
        
        # 处理音频数据
        batch = self.processor.feature_extractor.pad(
            input_features,
            padding=self.padding,
            return_tensors="pt",
        )
        
        # 提取并编码标签文本
        transcriptions = [feature["transcription"] for feature in features]
        
        # 使用tokenizer编码文本
        with self.processor.as_target_processor():
            labels_batch = self.processor.tokenizer(
                transcriptions,
                padding=True,
                return_tensors="pt",
            )
        
        # 将pad token替换为-100以在损失计算中忽略
        labels = labels_batch["input_ids"].masked_fill(
            labels_batch.attention_mask.ne(1), -100
        )
        
        batch["labels"] = labels
        
        return batch

# 计算CER
def compute_cer(pred):
    cer_metric = load_metric("cer")
    pred_logits = pred.predictions
    label_ids = pred.label_ids
    
    # 对于CTC模型，预测结果是logits，需要取argmax得到token ids
    pred_ids = np.argmax(pred_logits, axis=-1)
    
    # 替换-100为pad_token_id
    label_ids[label_ids == -100] = processor.tokenizer.pad_token_id
    
    # 解码预测和标签
    pred_str = processor.batch_decode(pred_ids, skip_special_tokens=True)
    label_str = processor.batch_decode(label_ids, skip_special_tokens=True)
    
    # 计算CER
    cer = cer_metric.compute(predictions=pred_str, references=label_str)
    return {"cer": cer}

# 自定义Trainer类
class CustomTrainer(Trainer):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.has_evaluated_initial = False  # 标记是否已经评估过初始模型
    
    def training_step(self, model, inputs):
        # 在第一次训练步骤前评估初始模型
        if not self.has_evaluated_initial:
            logging.info("评估初始模型...")
            initial_metrics = self.evaluate()
            logging.info(f"初始模型 CER = {initial_metrics.get('eval_cer', 'N/A'):.4f}")
            self.has_evaluated_initial = True
        
        # 执行训练步骤
        loss = super().training_step(model, inputs)
        
        # 每100步记录日志
        current_step = self.state.global_step
        if current_step % 100 == 0:
            current_epoch = self.state.epoch
            logging.info(f"Step {current_step} (Epoch {current_epoch:.2f}): Training in progress...")
        
        return loss

# 主函数
def main():
    global processor  # 使processor在compute_cer函数中可用
    
    # 模型和处理器路径
    model_path = "/scratch/s6070310/thesis/model/original_model/wav2vec2-large-xlsr-53-chinese-zh-cn"
    output_dir = "/scratch/s6070310/thesis/model/primary_model"
    os.makedirs(output_dir, exist_ok=True)
    
    # 数据路径
    train_dir = "/scratch/s6070310/thesis/data/train"
    val_dir = "/scratch/s6070310/thesis/data/val"
    
    # 加载模型和处理器
    logging.info("加载模型和处理器...")
    model = Wav2Vec2ForCTC.from_pretrained(model_path)
    processor = Wav2Vec2Processor.from_pretrained(model_path)
    
    # 加载数据集
    logging.info("加载数据集...")
    train_dataset = SpeechDataset(train_dir, train_dir + "/list.txt", processor)
    val_dataset = SpeechDataset(val_dir, val_dir + "/list.txt", processor)
    
    logging.info(f"训练集大小: {len(train_dataset)}")
    logging.info(f"验证集大小: {len(val_dataset)}")
    
    # 计算训练步数
    batch_size = 8
    gradient_accumulation_steps = 4
    effective_batch_size = batch_size * gradient_accumulation_steps
    steps_per_epoch = len(train_dataset) // effective_batch_size
    total_epochs = 70
    total_steps = steps_per_epoch * total_epochs
    
    logging.info(f"批次大小: {batch_size}")
    logging.info(f"梯度累积步数: {gradient_accumulation_steps}")
    logging.info(f"有效批次大小: {effective_batch_size}")
    logging.info(f"每epoch步数: {steps_per_epoch}")
    logging.info(f"总训练步数: {total_steps}")
    
    # 创建数据整理器
    data_collator = DataCollatorCTCWithPadding(processor=processor, padding=True)
    
    # 训练参数 - 修改为按epoch评估和保存
    training_args = TrainingArguments(
        output_dir=output_dir,
        per_device_train_batch_size=batch_size,
        per_device_eval_batch_size=batch_size,
        gradient_accumulation_steps=gradient_accumulation_steps,
        num_train_epochs=total_epochs,
        eval_strategy="epoch",  # 修改为每个epoch评估
        save_strategy="epoch",  # 修改为每个epoch保存
        logging_steps=100,
        save_total_limit=3,  # 修改为保留最近3个检查点
        logging_dir=log_dir,
        learning_rate=3e-4,
        warmup_steps=int(total_steps * 0.1),
        load_best_model_at_end=True,
        metric_for_best_model="cer",
        greater_is_better=False,
        report_to=["tensorboard"],  # 启用TensorBoard
        dataloader_num_workers=0,
        remove_unused_columns=False,
        push_to_hub=False,
        dataloader_pin_memory=True,
        fp16=True,  # 启用混合精度训练
    )
    
    # 初始化Trainer
    trainer = CustomTrainer(
        model=model,
        args=training_args,
        train_dataset=train_dataset,
        eval_dataset=val_dataset,
        data_collator=data_collator,
        compute_metrics=compute_cer,
    )
    
    # 检查是否有检查点
    checkpoint = None
    if os.path.exists(output_dir):
        checkpoints = sorted(
            [d for d in Path(output_dir).iterdir() if d.is_dir() and d.name.startswith("checkpoint-")],
            key=lambda x: int(x.name.split("-")[-1])
        )
        if checkpoints:
            checkpoint = str(checkpoints[-1])
            logging.info(f"从检查点 {checkpoint} 继续训练")
    
    # 开始训练
    logging.info("开始训练...")
    try:
        trainer.train(resume_from_checkpoint=checkpoint)
    except Exception as e:
        logging.error(f"训练过程中出现错误: {e}")
        raise
    
    # 保存最终模型
    final_model_path = os.path.join(output_dir, "final_model")
    trainer.save_model(final_model_path)
    processor.save_pretrained(final_model_path)
    logging.info(f"最终模型保存至 {final_model_path}")

if __name__ == "__main__":
    main()