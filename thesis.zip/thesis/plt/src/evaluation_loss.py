import re
import matplotlib.pyplot as plt

def parse_file(content):
    eval_loss_dict = {}
    for line in content.split('\n'):
        eval_match = re.search(r"{'eval_loss':\s*([\d.]+).*'epoch':\s*([\d.]+)}", line)
        if eval_match:
            loss = float(eval_match.group(1))
            epoch = float(eval_match.group(2))
            eval_loss_dict[epoch] = loss
    eval_loss = sorted(eval_loss_dict.items())
    return eval_loss

basic_content = open('basic_model_cer.txt', 'r').read()
primary_content = open('primary_model_cer.txt', 'r').read()
md_content = open('MD_model_cer.txt', 'r').read()
basic_eval_loss = parse_file(basic_content)
primary_eval_loss = parse_file(primary_content)
md_eval_loss = parse_file(md_content)

plt.figure(figsize=(10, 6))
plt.plot([e for e, _ in basic_eval_loss], [l for _, l in basic_eval_loss], label='Basic Model', marker='o')
plt.plot([e for e, _ in primary_eval_loss], [l for _, l in primary_eval_loss], label='Primary Model', marker='s')
plt.plot([e for e, _ in md_eval_loss], [l for _, l in md_eval_loss], label='MD Model', marker='^')
plt.xlabel('Epoch')
plt.ylabel('Evaluation Loss')
plt.title('Evaluation Loss Comparison')
plt.legend()
plt.grid(True)
plt.xticks(range(0, 51, 5))
plt.savefig('/scratch/s6070310/thesis/plt/evaluation_loss.png')
plt.show()