import re
import matplotlib.pyplot as plt

def parse_file(content):
    train_loss = []
    for line in content.split('\n'):
        train_match = re.search(r"{'loss':\s*([\d.]+).*'epoch':\s*([\d.]+)}", line)
        if train_match:
            loss = float(train_match.group(1))
            epoch = float(train_match.group(2))
            train_loss.append((epoch, loss))
    train_loss.sort()
    return train_loss

basic_content = open('basic_model_cer.txt', 'r').read()
primary_content = open('primary_model_cer.txt', 'r').read()
md_content = open('MD_model_cer.txt', 'r').read()
basic_train = parse_file(basic_content)
primary_train = parse_file(primary_content)
md_train = parse_file(md_content)

plt.figure(figsize=(10, 6))
plt.plot([e for e, _ in basic_train], [l for _, l in basic_train], label='Basic Model', marker='o')
plt.plot([e for e, _ in primary_train], [l for _, l in primary_train], label='Primary Model', marker='s')
plt.plot([e for e, _ in md_train], [l for _, l in md_train], label='MD Model', marker='^')
plt.xlabel('Epoch')
plt.ylabel('Training Loss')
plt.title('Training Loss Comparison')
plt.legend()
plt.grid(True)
plt.xticks(range(0, 51, 5))
plt.savefig('/scratch/s6070310/thesis/plt/training_loss.png')
plt.show()