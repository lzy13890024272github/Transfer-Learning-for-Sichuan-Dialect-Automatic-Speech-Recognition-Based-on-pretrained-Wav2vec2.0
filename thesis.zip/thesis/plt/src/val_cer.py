import re
import matplotlib.pyplot as plt

def parse_file(content):
    eval_cer_dict = {}
    for line in content.split('\n'):
        eval_match = re.search(r"'eval_cer':\s+([\d.]+).*?'epoch':\s+([\d.]+)", line)
        if eval_match:
            cer = float(eval_match.group(1))
            epoch = float(eval_match.group(2))
            eval_cer_dict[epoch] = cer
    eval_cer = sorted(eval_cer_dict.items())
    return eval_cer

basic_content = open('basic_model_cer.txt', 'r').read()
primary_content = open('primary_model_cer.txt', 'r').read()
md_content = open('MD_model_cer.txt', 'r').read()
basic_eval_cer = parse_file(basic_content)
primary_eval_cer = parse_file(primary_content)
md_eval_cer = parse_file(md_content)

plt.figure(figsize=(10, 6))
plt.plot([e for e, _ in basic_eval_cer], [c for _, c in basic_eval_cer], label='Basic Model', marker='o')
plt.plot([e for e, _ in primary_eval_cer], [c for _, c in primary_eval_cer], label='Primary Model', marker='s')
plt.plot([e for e, _ in md_eval_cer], [c for _, c in md_eval_cer], label='MD Model', marker='^')
plt.xlabel('Epoch')
plt.ylabel('Evaluation CER')
plt.title('Evaluation CER Comparison')
plt.legend()
plt.grid(True)
plt.xticks(range(0, 51, 5))
plt.savefig('/scratch/s6070310/thesis/plt/evaluation_cer.png')
plt.show()